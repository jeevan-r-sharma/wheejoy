<!DOCTYPE html>
<html>
<?php include('common.php'); ?>

<script type="text/javascript">
function get_today_subscription()
{
    // $.ajax({
    //     type: "GET",
    //     url: "<?php echo base_url(); ?>dashboard/TotalAdmissionsAdm",
    //     cache: false,
    //     data: $('#frmAgent').serialize(),
    //     success: function(data) {
    //             //alert(data);
    //             var e1 = JSON.parse(data);
    //             if (e1.length > 0) {
    //                 $("#example2").find("tr:gt(0)").remove();
    //                 var table = document.getElementById("example2");
    //                 for (var i = 0; i < e1.length; i++)
    //                 {
    //                     var tab = table.insertRow(i + 1);
    //                     var col1 = tab.insertCell(0);
    //                     $(col1).addClass("text-center");
    //                     col1.innerHTML =i+1;
    //                     var col2 = tab.insertCell(1);
    //                     $(col2).addClass("text-center");
    //                     col2.innerHTML = e1[i]['fullname']; 
    //                     var col3 = tab.insertCell(2);
    //                     $(col3).addClass("text-center");
    //                     col3.innerHTML = e1[i]['phonenumber'];
    //                     var col4 = tab.insertCell(3);
    //                     $(col4).addClass("text-center");
    //                     col4.innerHTML = e1[i]['email'];
                        

    //                 }
    //             } else {
    //                 //alert("no record found");
    //             }
    //         },
    //         error: function() {
    //         }
    //     });
}
function today_sub()
{
    $.ajax({
        type: "GET",
        url: "<?php echo base_url(); ?>dashboard/todaySubcriptionCount_adm",
        cache: false,
        data: $('#frmAgent').serialize(),
        success: function(data) {
            try {
//                         alert(data);
objt = jQuery.parseJSON(data);
                    // alert(objt[0].sub);
                    document.getElementById('login').innerHTML = "Today's Login = " + objt[0].loginid;
                    document.getElementById('today').innerHTML = "Registration Today = " + objt[0].reg;
//                        document.getElementById('sub').innerHTML = "Subscription Today = " + objt[0].sub;
//                        document.getElementById('sum').innerHTML = "Today Amount collected = " + objt[0].total;
//                        
} catch (e) {
}
},
error: function() {
}
});
}
function week_sub()
{
    $.ajax({
        type: "GET",
        url: "<?php echo base_url(); ?>dashboard/weeklySubscription",
        cache: false,
        data: $('#frmAgent').serialize(),
        success: function(data) {
            try {
                objw = jQuery.parseJSON(data);
                document.getElementById('week').innerHTML = "Registration Weekly  = " + objw[0].reg;
//                        document.getElementById('subb').innerHTML = "Subscription Weekly  = " + objw[0].sub;
//                        document.getElementById('summ').innerHTML = "Weekly Amount collected = " + objw[0].sum;
} catch (e) {
}
},
error: function() {
}
});
}
function month_sub()
{
    $.ajax({
        type: "GET",
        url: "<?php echo base_url(); ?>dashboard/monthlySubscription",
        cache: false,
        data: $('#frmAgent').serialize(),
        success: function(data) {
            try {
                    // alert(data);
                    objm = jQuery.parseJSON(data);
                    document.getElementById('month').innerHTML = "Registration Monthly = " + objm[0].reg;
//                        document.getElementById('subbb').innerHTML = " Subscription Monthly= " + objm[0].sub;
//                        document.getElementById('summm').innerHTML = "Monthly Amount collected  = " + objm[0].sum;
} catch (e) {
}
},
error: function() {
}
});
}
function overall_sub()
{
    $.ajax({
        type: "GET",
        url: "<?php echo base_url(); ?>dashboard/getOverallSubscription",
        cache: false,
        data: $('#frmAgent').serialize(),
        success: function(data) {
            try {
                obj = jQuery.parseJSON(data);
                document.getElementById('over').innerHTML = "OverAll Subscription =" + obj[0].id;
            } catch (e) {
            }
        },
        error: function() {
        }
    });
}
function onload()
{
    today_sub();
    week_sub();
    month_sub();
    overall_sub();
}
</script>
<body onload="get_today_subscription(), onload()">
<!--          Right side column. Contains the navbar and content of the page -->
<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Dashboard
        </h1>
        <ol class="breadcrumb">
            <li class="active"><a href="<?php echo base_url(); ?>dashboard">Home</a></li>

        </ol>
    </section>

    <!-- Main content -->
    <section class="content">

        <!-- Small boxes (Stat box) -->
        <div class="row">
            <div class="col-lg-3 col-xs-6 col-sm-3">
                <!-- small box -->

                <div class="small-box bg-aqua">
                    <div class="inner">                                    
                        <span class="col-md-5 col-xs-6"><h3 class="avg-score"></h3></span><span class="col-md-7 col-xs-6"><h4 class="score pull-right"></h4></span>
                        <div class="clearfix"></div>
                        <p></p>
                        <p id="login"></p>
                        <p id="today"></p>
<span class="col-md-5 col-xs-6"><h3 class="avg-score"></h3></span><span class="col-md-7 col-xs-6"><h4 class="score pull-right"></h4></span>
<div class="clearfix"></div>
<span class="col-md-5 col-xs-6"><h3 class="avg-score"></h3></span><span class="col-md-7 col-xs-6"><h4 class="score pull-right"></h4></span>
<div class="clearfix"></div>
<p></p>
</div>
</div>
</div><!-- ./col -->

<div class="col-lg-3 col-xs-6 col-sm-3">
<!-- small box -->
<div class="small-box bg-green">
    <div class="inner">
        <span class="col-md-5 col-xs-6"><h3 class="avg-score"></h3></span><span class="col-md-7 col-xs-6"><h4 class="score pull-right"><h4 class="score pull-right"></h4></span>
        <div class="clearfix"></div>
        <p></p>
        <p id="week"></p>
            <span class="col-md-5 col-xs-6"><h3 class="avg-score"></h3></span><span class="col-md-7 col-xs-6"><h4 class="score pull-right"></h4></span>
<div class="clearfix"></div>
<p></p>
<p></p>

</div>
</div>
</div>
<!-- ./col -->
<div class="col-lg-3 col-xs-6 col-sm-3">
<!-- small box -->
<div class="small-box bg-yellow">
    <div class="inner">

        <span class="col-md-5 col-xs-6"><h3 class="avg-score"></h3></span><span class="col-md-7 col-xs-6"><h4 class="score pull-right"><h4 class="score pull-right"></h4></span>
        <div class="clearfix"></div>
        <p></p>
        <p id="month"></p>
<!--                                <p id="subbb"></p>
<p id="summm"></p>-->

<span class="col-md-5 col-xs-6"><h3 class="avg-score"></h3></span><span class="col-md-7 col-xs-6"><h4 class="score pull-right"></h4></span>
<div class="clearfix"></div>
<p></p>
<p></p>

</div>
</div>
</div><!-- ./col -->
<div class="col-lg-3 col-xs-6 col-sm-3">
<!-- small box -->
<div class="small-box bg-red">
    <div class="inner">

        <span class="col-md-5 col-xs-6"><h3 class="avg-score"></h3></span><span class="col-md-7 col-xs-6"><h4 class="score pull-right"><h4 class="score pull-right"></h4></span>
        <div class="clearfix"></div>
        <p></p>
        <p id="over"></p>
        <p></p>

        <span class="col-md-5 col-xs-6"><h3 class="avg-score"></h3></span><span class="col-md-7 col-xs-6"><h4 class="score pull-right"></h4></span>
        <div class="clearfix"></div>
        <p></p>
        <p></p>

    </div>
</div>
</div><!-- ./col -->
</div><!-- /.row -->

<!-- Main row -->
<div class="row">
<br/>  


<!--accordian-->
<form id="frmAgent">
    <div class="bs-example pull-left ext-width">
        <div class="panel-group">
            <br/>
            
            <div class="panel panel-default">
                <div class="panel-heading">

                    <h4 class="panel-title text-center">
                        <b>Todays Registration</b>
                    </h4>
                    
                </div>
                <div  class="panel-collapse collapse in col-lg-offset-1 col-lg-10">
                    <div class="panel-body panel-body-border">
                        <div class="box-body table-responsive">
                            <div id="example2_wrapper" class="dataTables_wrapper form-inline" role="grid">
                                <div class="row"><div class="col-xs-6"></div><div class="col-xs-6"></div></div>
                                <div id="pagelink" class="pagination pull-right"><?php
                                                if (isset($result_per_page)) {
                                                    echo $this->pagination->create_links();
                                                }
                                                ?>
                                </div>
                                <table aria-describedby="example2_info" id="example2" class="table table-bordered table-hover dataTable">
                                    <tbody aria-relevant="all" aria-live="polite" role="alert">
                                        <tr class="odd black">
                                            <td class="text-center">SR NO</td>
                                            <td class="text-center">Student Name</td>
                                            <td class="text-center">Phone No.</td>
                                            <td class="text-center">Email</td>                                              
                                            <!--<td class="text-center">Amount</td>-->      
                                        </tr>
                                        <!--</tr>-->
                                        <tr class="even">
                                                
                                                <?php $i=1;
                                                $j=$this->session->userdata('count')+1;
//                                                        while($i<$count)
                                                if($j>0){   
                                                    foreach($result_per_page as $row){?>
                                                    <tr class="even">
                                                        <td class="text-center"><?php echo $j; ?></td>
                                                        <td class="text-center"><?php echo $row->fullname; ?></td> 
                                                        <td class="text-center"><?php echo$row->phonenumber; ?></td>     
                                                        <td class="text-center"><?php echo $row->email; ?></td>
                                                    </tr>
                                            <?php  $i = $i+1; $j++;
                                        }
                                    } else {
                                        echo '<tr><td colspan="9" style="color: red;">No Records Found</td></tr>';
                                    }
//                                            ?>   

                                    </tbody>
                                </table>
                            </div>
                        </div><!-- /.box-body -->
                    </div>                      
                </div>
            </div>
        </div>
    </div></form>
    <br/><br/><br/>
    <!-- accordian end -->
</section>


</div><!-- /.row (main row) -->

</section><!-- /.content -->
</aside><!-- /.right-side -->
</div><!-- ./wrapper -->
</body>
</html>