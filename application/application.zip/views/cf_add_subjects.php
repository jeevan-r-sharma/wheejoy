    <!DOCTYPE html>
    <html>

    <?php include('common.php'); ?>  
    <body> 

        <!-- Right side column. Contains the navbar and content of the page -->
        <aside class="right-side">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>
                    Add Subject
                </h1>
                <ol class="breadcrumb">
                    <li><a href="<?php echo base_url(); ?>dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
                    <!--                        <li>Refer A Friend</li>-->

                    <li class="active">Add Subject</li>
                </ol>
            </section>
            <aside>
                <section class="content-header">
                    <div class="row">		
                        <div class="col-lg-12 col-md-12">				
                            <div class="row form-3">	
                                <!-- <h5 class="form-title"></h5> -->
                                <!-- form-3-start	 -->
                                <form class="form-horizontal form-shade" id="myform" name="myform">
                                    <input type="button" id="pop" name="pop" class="btn btn-primary" data-toggle="modal" data-target="#GSCChelp2" style="display:none"/>
                                    <input type="text" class="form-control" id="pop_id" name="pop_id" style="display:none"/>
<!--                                     <div class="form-group">
                                        <label for="text1" class="control-label col-lg-4">Exam Name</label>
                                        <div class="col-lg-5">
                                            <select class="form-control" id="examid" name="exam" onchange="javascript:get_subject()">
                                                <option value="0">Select Exam</option>
                                                <?php
                                                $c = count($a);
                                                $i = 0;
                                                while($i <$c){
                                                    echo('<option value="'.$a[$i]->id.'">'.$a[$i]->name.'</option>');
                                                    $i++;
                                                }
                                                ?>
                                            </select>						
                                        </div>
                                    </div>   -->   

                                    <div class="form-group">
                                        <label for="text1" class="control-label col-lg-4">Subject</label>
                                        <div class="col-lg-5">
                                            <input type="text" placeholder="" class="form-control" value="" id="subject" name="Subject Name"/>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="text1" class="control-label col-lg-4">Description</label>
                                        <div class="col-lg-5">
                                            <input type="text" placeholder="" class="form-control" value="" id="description" name="Description"/>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-lg-9">
                                            <a href="#" class="btn btn-primary pull-right" id="add" onclick="insert_subject()">ADD</a>

                                        </div>	
                                    </div>

                                </form>
                            </div>
                        </div>

                    </div>  
                </section><!-- /.content -->
                <section class="col-lg-12 connectedSortable">

                    <div class="box-body table-responsive">
                        <div id="example2_wrapper" class="dataTables_wrapper form-inline" role="grid">
                            <div class="col-md-12 text-center"><h3></h3></div> 
                            <div class="row"><div class="col-xs-6"></div><div class="col-xs-6"></div></div>

                            <table aria-describedby="example2_info" id="example2" class="table table-bordered table-hover dataTable">

                                <tbody aria-relevant="all" aria-live="polite" role="alert">                                                    
                                    <tr class="odd black">
                                        <td class="hide"></td>
                                        <td class="text-center" style="width: 80px;">S No.</td>
                                        <td class="text-center">Subject</td>
                                        <!-- <td class="text-center">Description</td> -->
                                        <!-- <td class="text-center">Created on</td> -->
                                        <td class="text-center">Edit</td>
                                        <td class="text-center">Delete</td>
                                    </tr> 

                                    <?php
                                    $c = count($s);
                                    $i = 0;
                                    if ($c > 0) {
                                        while ($i < $c) {
                                            ?>
                                            <tr class="even">												                                             
                                                <td class="hide"><?php echo $s[$i]->id; ?></td>
                                                <td class="text-center"><?php echo $i + 1; ?></td> 
                                                <td class="text-center"><?php echo $s[$i]->description; ?></td> 
                                                <!-- <td class="text-center"><?php echo $s[$i]->description; ?></td>  -->
                                                <!-- <td class="text-center"><?php echo $s[$i]->created_on; ?></td>  -->
                                                <td class="text-center"><a href="#" class="btn btn-primary" onclick="edit_record('<?php echo $s[$i]->id; ?>',
                                                   '<?php echo $s[$i]->description; ?>');">Edit</a>
                                               </td>
                                               <td class="text-center"><a href="#" class="btn btn-primary" onclick="delete_record(<?php echo $s[$i]->id; ?>);">Delete</a></td>  

                                           </tr>
                                           <?php
                                           $i++;
                                       }
                                   } else {
                                    echo '<tr><td colspan="5" style="color: red;">No Records Found</td></tr>';
                                }
                                ?>
                            </tbody></table>

                        </div>
                    </div><!-- /.box-body -->

                </form>
            </div>
        </div>

    </div>  
</section><!-- /.content -->
                    <!--pop up-->
            <div id="GSCCModal4" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content" style="margin-top:15%;">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;  </button>
            <h4 class="modal-title" id="myModalLabel"><b>Edit Subjects</b></h4>
            </div>
            <div class="modal-body">
            <div class="row">
            <div class="col-lg-12">
            <div class="form-group">
                <label for="text1" class="control-label col-lg-3 col-md-3 col-sm-3 col-xs-12">Subject Name</label>
                <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                    <input type="text" placeholder="" class="form-control" value="" id="edit_name" name="name"/>
                </div>	
            </div>
<!--             <div class="form-group">
                <label for="text1" class="control-label col-lg-3 col-md-3 col-sm-3 col-xs-12">Description</label>
                <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                    <input type="text" placeholder="" class="form-control" value="" id="edit_desc" name="desc"/>
                </div>	
            </div> -->
            </div>
            </div>
            </div>
            <div class="modal-footer" style="border-top:none;">
                <input  type="button" id="upload" value="add" onclick="update()"class="btn btn-primary custom-btn" />
                <input  type="button" id="upload" value="add" onclick="update()"class="btn btn-primary custom-btn" />
            <!---<button type="button" class="btn btn-primary">Save changes</button>-->
        </div>                              
    </div>
</div>
</div> 
            <!--pop up end-->
                    <div id="popup_message" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
                        <div class="modal-dialog custom-alert">
                            <div class="modal-content" style="margin-top:20%;">
                                <div class="modal-header alert-success">
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="javascript:location.href = ''">&times; </button>
                                    <h4 class="modal-title" id="myModalLabel">Message</h4>
                                </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-lg-12" id="message">
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer alert-footer">
                                    <a href="javascript:location.href=''" class="btn btn-success">ok</a>
                                </div>
                            </div>
                        </div>
                    </div>
                     <div id="popup_error" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
                        <div class="modal-dialog custom-alert">
                            <div class="modal-content" style="margin-top:20%;">
                                <div class="modal-header alert-success">
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="">&times; </button>
                                    <h4 class="modal-title" id="myModalLabel">Message</h4>
                                </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-lg-12" id="error_message">
                                        </div>
                                    </div>
                                </div>  
                                <div class="modal-footer alert-footer">
                                    <a href="#" class="btn btn-success" data-dismiss="modal">ok</a>
                                </div>
                            </div>
                        </div>
                    </div>  
                        <button class="hide" id="popupbutton" data-toggle='modal' data-target='#GSCCModal4'>Edit</button>
                       <button class="hide" id="popup_button" data-toggle="modal" data-target="#popup_message"></button>
                       <button class="hide" id="popup_button2" data-toggle="modal" data-target="#popup_error"></button>
                   </aside><!-- /.right-side -->
               </div><!-- ./wrapper -->


               <!--pop up2-->
               <div id= "GSCChelp2" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content" style="margin-top:25%;">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times; </button>
                            <h4 class="modal-title" id="myModalLabel">Delete subject</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <h4 class=" text-center">Are you sure to delete subject?</h4>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <div class=" pull-right">
                                <input type="button" class="btn btn-primary" value="YES" data-dismiss="modal" onclick="delete_subject();"/>
								<button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                                <!--a href="javascript:addChapter();" id ="con" data-dismiss="modal" class="btn btn-primary pull-right">Add Chapter</a-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                    <!--end of popup-->  
                                                                
                                                        
                                                                
                                     
                    
                    
    </body>
    <script>
        var e_id = 0;
        function getupload()
        { 
            alert("hi");
        }
                                                  
        function insert_subject()
        {
            $("#error_message").empty();
            if ($('#subject').val() == '')
            {
                $("#popup_button2").click();
                $("#error_message").append("Please Fill Subject");
                return;
            }
            else if ($('#description').val() == '')
            {
                $("#popup_button2").click();
                $("#error_message").append("Please Fill Description");
                return;
            }
             else
                 var exam_id = 1; // not considered
                 var subject_name = document.getElementById('subject').value;
                 var description = document.getElementById('description').value;
              
             $.ajax({
    		type: "POST",
    		url: "<?php echo base_url();?>admin/insertmastercf_subject",
    		cache: false,				
    		data: {exam_id:exam_id,subject_name:subject_name,description:description},
    		success: function(data){						
    //			  alert(data);
                        $("#terror1").hide();
                        $("#message").empty();
                        if (data != 0)
                        {
                            $("#popup_button").click();
                            $("#message").append("Subject Added Succesfully");
                        }
                        else
                        {
                            $("#popup_button").click();
                            $("#message").append("Sorry, Something went wrong");
                        }
                    },
                    error: function (err)
                    {
                        alert("Error while request");
                        alert(JSON.stringify(err));
                    }
                });
        }
       function get_subject()
        {
                var exam = $('#examid').val();
    //            alert(exam);
                var drpDown = document.getElementById('subject');
                drpDown.innerHTML ='';
                  //alert("called");
                  $.ajax({
                       type: "POST",
                       url: "<?php echo base_url();?>admin/get_cf_subject",
                       cache: false,				
                       data:{exam:exam}, 
                       success: function(data){						
    //                        alert(data);
                            try{
                                    if(data.length>2)
                                    {
                            obj = jQuery.parseJSON(data);
    //                    objdistrict = jQuery.parseJSON(data);
                        var el = document.createElement("option");
                        el.textContent = "Select Subject";
                        el.value = "0";
                        drpDown.appendChild(el);
                        for (i = 0; i < obj.length; i++)
                        {
                        var opt = obj[i]['id'];
                        var desc = obj[i]['name'];
                        var el = document.createElement("option");
                        el.textContent = desc;
                        el.value = opt;
                        drpDown.appendChild(el);
                        }
                                        
         
                               while (document.getElementById("example2").firstChild) {
                    document.getElementById("example2").removeChild(document.getElementById("example2").firstChild);
                    }
                    document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
                        "<td class='hide'></td>"+
                        "<td class='text-center'>S No.</td>"+
                        
                        "<td class='text-center'>subject</td>"+
                        
                        "<td class='text-center'>Description</td>"+
                        
                        
                        
                        "</tr>";
                                        j=1;
                             for(i=0;i<obj.length;i++)
                             {                             
                                document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+
                                "<tr>"+
                                "<td class='hide' >"+obj[i].id+"</td>"+
                                "<td class='text-center'>"+ j +"</td>"+
                                "<td class='text-center'>"+obj[i].name+"</td>"+
                                "<td class='text-center'>"+obj[i].description+"</td>"+
                               
                               
                                "</tr>"
                                ;
                               j++;
                            }
                                    }
                               else
                               {
                               document.getElementById("example2").innerHTML = "";
                               document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
                                                "<td class='hide'></td>"+
                                                "<td class='text-center'>S No.</td>"+
                                                "<td class='text-center'>Subject</td>"+
                                                "<td class='text-center'>Description</td>"+

                                                
                                            "</tr>";
                                    document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
                                                
                                                
                                            "<tr><td colspan='6' style='color:red;'>No Record Found</td></tr>";
                                            
                               }
                                
                               
                            }catch(e) {		
                            } 
                       },
                       
                       error: function(){						
                            //alert('Error while request..');
                       } 
                    });                
                    
        }

        function delete_record(id)
        {
            document.getElementById('pop_id').value=id;
            document.getElementById('pop').click();
        }
        function delete_subject(){
            var id=document.getElementById('pop_id').value;
            $.ajax({
                type : "post",
                url : '<?php echo base_url(); ?>admin/delete_cf_subject',
                catche : false,
                data : {subject_id:id},
                success : function(data){
                    try{
    //                    alert('Updated Success');
                        location.href = "<?php echo base_url(); ?>admin/addSubjects";
    //                      get_details_college();
                    }catch(e){
                        
                    }
                },
                error:function(){
                    
                }
            });
        }
        
        function edit_record(eid,ename,edesc){
        e_id = eid;
        document.getElementById('edit_name').value=ename;
        // document.getElementById('edit_desc').value=edesc;
        
        $("#popupbutton").click();
        }
        function update(){
        $("#error_message").empty();
            if ($('#edit_name').val() == '')
            {
                $("#popup_button2").click();
                $("#error_message").append("Please fill Name field");
                return;
            }
            else
                var eidd = e_id;
                var ename = document.getElementById('edit_name').value;
                // var edesc = document.getElementById('edit_desc').value;
            $.ajax({
                    type: "POST",
                    url: "<?php echo base_url(); ?>admin/editSubject",
                    catche : false,
                    data: {eidd:eidd,ename:ename},
                    success: function (data)
                    {
    //                    alert(data);
                        $("#terror1").hide();
                        $("#message").empty();
                        if (data != 0)
                        {
                            $("#popup_button").click();
                            $("#message").append("Edited Succesfully");
                        }
                        else
                        {
                            $("#popup_button").click();
                            $("#message").append("Sorry, Something went wrong");
                        }
                    },
                    error: function (err)
                    {
                        alert("Error while request");
                        alert(JSON.stringify(err));
                    }
                });
        }
    </script>
    </html>

