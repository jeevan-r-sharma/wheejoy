
<!doctype html>
<html>
    <?php include('common.php'); ?>
    <head>

    </head>
    <body>
        <aside class="right-side">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>
                    New Registration
                </h1>
                <ol class="breadcrumb">
                    <li><a href="<?php echo base_url(); ?>dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
                    <!--                        <li>Refer A Friend</li>-->

                    <li class="active"> Free Loaded</li>
                </ol>
            </section>
            <aside>
                <section class="content">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <div class="row form-3">
                                <h5 class="form-title"> Activate User</h5>
                                <!--------------------------------------form-3-start------------------------------------->
                                <form class="form-horizontal form-shade" id="myInfo" name="myInfo">
                                    <div class="form-group">
                                        <label for="text1" class="control-label col-lg-4"></label>
                                        <div class="col-lg-5">
                                            <input type="text" name="name" id="name" value ="" autocomplete="off" class="form-control" placeholder="EnterName" required/>
                                            <a href="javascript:makeAjaxGetVal()" id ="search"  class="btn btn-primary pull-right" style="display:block;margin:0 3px;">Search Friends</a>
                                        </div>
                                    </div>
                                    <span style="color:red" id="error"></span>


                                    <div class="">
                                        <table class="table table-bordered">
                                            <tbody id="members">
                                            </tbody></table>  
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>                  

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->        
</body>
<script type="text/javascript">
    function makeAjaxGetVal() {
        //alert("hi");
        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>free_loaded/search_by_name",
            cache: false,
            data: $('#myInfo').serialize(),
            success: function (json) {
                // alert(json);
                try {
                    if (json == 0) {
                        document.getElementById("members").innerHTML = "";
                        document.getElementById("error").innerHTML = "No Data Found For This Details";
                    }
//                      
                    else {
                        var obj = jQuery.parseJSON(json);
//                                  alert(obj[0].first_name);
                        while (document.getElementById("members").firstChild) {
                            document.getElementById("members").removeChild(document.getElementById("members").firstChild);
                        }
                        document.getElementById("members").innerHTML = document.getElementById("members").innerHTML + "<tr>" +
                                "<td class='hide'>user_id</td>" +
                                "<th>Student Name</th>" +
                                "<th class='hide'>last Name</th>" +
                                "<th>Phone</th>" +
                                "<th>Email_id</th>" +
                                "<th>Status</th>" +
                                "</tr>";
                        //var count=0;
                        for (i = 0; i < obj.length; i++)
                        {
                            var userid = obj[i].userid;
                            document.getElementById("members").innerHTML = document.getElementById("members").innerHTML +
                                    "<tr>" +
                                    "<td class='hide'><input type='text' id='uid' name='uid' value='" + obj[i].userid + "'>" + "</td>" +
                                    "<td>" + obj[i].first_name + "</td>" +
                                    "<td class='hide'>" + obj[i].last_name + "</td>" +
                                    "<td>" + obj[i].phonenumber + "</td>" +
                                    "<td>" + obj[i].email_id + "</td>" +
                                    "<td><input type='button' value='Activate' onclick=activate("+userid+");></td>" +
                                    "</tr>"
                                    ;
                            document.getElementById("error").innerHTML = "";

                        }
                    }

                } catch (e) {

                }
            },
            error: function () {
                alert('Exception while request..');
            }
        });
    }



    function activate()
    {
        var uid = document.getElementById('uid').value;
        //alert(uid);
        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>free_loaded/activate_student",
            cache: false,
            data: $('#myInfo').serialize(),
            success: function (json) {
//                alert(json);
                try {
                if(json==1){                
                    alert("User Account Activated!");
                    makeAjaxGetVal();
                }
                else
                    alert("Failed to activate!");
                } catch (e) {
                    alert('Exception while request..');
                }
            },
            error: function () {
            }
        });
    }

</script>
</html>    