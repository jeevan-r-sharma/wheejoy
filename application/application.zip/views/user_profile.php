<!DOCTYPE html>
<html>
    
 <?php include('common.php'); ?>    

 <body> 


    <!-- Right side column. Contains the navbar and content of the page -->
    <aside class="right-side">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                User Profile
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo base_url(); ?>dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
                <!--                        <li>Refer A Friend</li>-->

                <li class="active">sign out</li>
                <li class="active">profile</li>
            </ol>
        </section>
        <aside>
            <section class="content">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="row form-3">
                            <!--<h5 class="form-title">User Details</h5>-->
                            <!-- form-3-start -->
                            <form class="form-horizontal form-shade" name="myInfo" id="myInfo" >
                                <div class="form-group">
                                <?php
                                $co = count($g[0]);
                                $i = 0;
                                while ($i < $co) {
                                    ?>
                                    <div class="form-group" style="display: none">
                                        <div class="col-lg-5 col-md-8 col-sm-8 col-xs-12">
                                            <input type="text" placeholder="" class="form-control1" id="id" readonly="" name="id" value="<?php echo $g[0][$i]->id ; ?>" />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="text1" class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12">Full Name</label>
                                        <span style="color:red" id="errorfn"></span>
                                        <div class="col-lg-5 col-md-8 col-sm-8 col-xs-12">
                                            <input type="text" placeholder="Full Name" class="form-control1" id="full_name" readonly="" name="first_name" value="<?php echo $g[0][$i]->name ; ?>" onblur="validate_fname();"/>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="text1"
                                        class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12">Email-id</label>
                                        <span style="color:red" id="error-email"></span>
                                        <div class="col-lg-5 col-md-8
                                        col-sm-8 col-xs-12">
                                        <input type="text" placeholder="Email" class="form-control1" id="emailid" name="emailid" value="<?php echo $g[0][$i]->email_id ; ?>" readonly=""/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="text1" class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12">user Name</label>
                                    <span style="color:red" id="errorln"></span>
                                    <div class="col-lg-5 col-md-8 col-sm-8 col-xs-12">
                                        <input type="text" placeholder="user Name" class="form-control1" id="user_name" name="last_name" value="<?php echo $g[0][$i]->user_name ; ?>" readonly="" onblur="validate_lname();"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="text1" class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12">Password</label>
                                    <span style="color:red" id="errorln"></span>
                                    <div class="col-lg-5 col-md-8 col-sm-8 col-xs-12">
                                        <input type="text" placeholder="Password" class="form-control1" id="password" name="Password" value="<?php echo $g[0][$i]->password ; ?>" readonly="" onblur="validate_lname();"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="text1" class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12">Contact Number</label>
                                    <span style="color:red" id="errorphone"></span>
                                    <div class="col-lg-5 col-md-8 col-sm-8 col-xs-12">
                                        <input placeholder="Your Phone" type="text" class="form-control1" value="<?php echo $g[0][$i]->contact_no ; ?>" readonly="" pattern="\d{3}[\-]\d{3}[\-]\d{4}" maxlength="10"  name="contact" id="contact" data-mask="999-999-9999" onfocusout="validate_phone(document.myInfo.contact.value);"  onchange="javascript:ajxContact();"/>
                                        <!--                                            <span style="color:red" id="error1"></span>-->
                                    </div>
                                </div>
                                <?php
                                $i++;
                            }
                            ?>

                            <div class="form-group" id="edit_full">
                                <div class="col-lg-9">
                                    <a href="#" class="btn btn-primary pull-right" id="edit" name="bttn" onclick="edit_user_profile();">Edit</a>

                                </div>	
                            </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div> 

        </section><!-- /.content -->      
    </aside>
                        <div class="clearfix">&nbsp;</div>
                        <div id="tab" name="tab" style="display:none;" class="box-body table-responsive">
                            <div id="example2_wrapper" class="dataTables_wrapper form-inline" role="grid">
                                <div class="row"><div class="col-xs-6"></div><div class="col-xs-6"></div></div>
                                <table aria-describedby="example2_info" id="example3" class="table table-bordered table-hover dataTable">
                                    <!--<tbody aria-relevant="all" aria-live="polite" role="alert"><tr class="odd black">-->
                                    <tr class="odd black">
                                        <td class="text-center">SR NO</td>
                                        <td class="text-center">User ID</td>
                                        <td class="text-center">First Name</td>
                                        <td class="text-center">Last Name</td>
                                        <td class="text-center">Password</td>
                                        <td class="text-center">Date Of Birth</td>
                                        <td class="text-center">Gender</td>
                                        <td class="text-center">College Name</td>
                                        <td class="text-center">Email ID</td>
                                        <td class="text-center">Subscription</td>
                                        <td class="text-center">Status</td>
                                    </tr>
                                    <!--</tbody>-->
                                </table>
                            </div>
                        </div><!-- /.box-body -->




        <!--                    </form>-->
    
    <!--pop up-->
    <div id="GSCCModal4" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" style="margin-top:15%;">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;  </button>
                    <h4 class="modal-title" id="myModalLabel"><b>Edit Users</b></h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label for="text1" class="control-label col-lg-3 col-md-3 col-sm-3 col-xs-12">Full Name</label>
                                <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                                    <input type="text" placeholder="" class="form-control" value="" id="edit_name" name="name"/>
                                </div>	
                            </div>
                            <div class="form-group">
                                <label for="text1" class="control-label col-lg-3 col-md-3 col-sm-3 col-xs-12">Email-ID</label>
                                <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                                    <input type="text" placeholder="" class="form-control" value="" id="edit_email" name="Email"/>
                                </div>	
                            </div>
                            <div class="form-group">
                                <label for="text1" class="control-label col-lg-3 col-md-3 col-sm-3 col-xs-12">User Name</label>
                                <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                                    <input type="text" placeholder="" class="form-control" value="" id="edit_user" name="User"/>
                                </div>	
                            </div>
                            <div class="form-group">
                                <label for="text1" class="control-label col-lg-3 col-md-3 col-sm-3 col-xs-12">Password</label>
                                <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                                    <input type="text" placeholder="" class="form-control" value="" id="edit_pass" name="Password"/>
                                </div>	
                            </div>
                            <div class="form-group">
                                <label for="text1" class="control-label col-lg-3 col-md-3 col-sm-3 col-xs-12">Phone Number</label>
                                <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                                    <input type="text" placeholder="" class="form-control" value="" id="edit_phone" name="Phone"/>
                                </div>	
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer" style="border-top:none;">
                    <input  type="button" id="upload" value="Add" onclick="update()"class="btn btn-primary custom-btn" />
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <!---<button type="button" class="btn btn-primary">Save changes</button>-->
                </div>                              
            </div>
        </div>
    </div> 
    <!--pop up end-->
    <div id="popup_message" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog custom-alert">
            <div class="modal-content" style="margin-top:20%;">
                <div class="modal-header alert-success">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="javascript:location.href = ''">&times; </button>
                    <h4 class="modal-title" id="myModalLabel">Message</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12" id="message">
                        </div>
                    </div>
                </div>
                <div class="modal-footer alert-footer">
                    <a href="javascript:location.href=''" class="btn btn-success">ok</a>
                </div>
            </div>
        </div>
    </div>
    <div id="popup_error" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog custom-alert">
            <div class="modal-content" style="margin-top:20%;">
                <div class="modal-header alert-success">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="">&times; </button>
                    <h4 class="modal-title" id="myModalLabel">Message</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12" id="error_message">
                        </div>
                    </div>
                </div>  
                <div class="modal-footer alert-footer">
                    <a href="#" class="btn btn-success" data-dismiss="modal">ok</a>
                </div>
            </div>
        </div>
    </div>  
    <button class="hide" id="popupbutton" data-toggle='modal' data-target='#GSCCModal4'>Edit</button>
    <button class="hide" id="popup_button" data-toggle="modal" data-target="#popup_message"></button>
    <button class="hide" id="popup_button2" data-toggle="modal" data-target="#popup_error"></button>
</aside><!-- /.right-side -->
<!-- </div>./wrapper -->

</body>
    <script type="text/javascript">
       function validate_fname()
       {
        var fn=document.getElementById("full_name").value;
        var name=(/^([a-z ,A-Z])+$/);
        if(!fn.match(name))
        {
         document.getElementById("errorfn").innerHTML="Please enter a valid first name";
         document.getElementById("full_name").value="";
         document.getElementById("full_name").focus();
     }
     else
     {
      document.getElementById("errorfn").innerHTML="";
  }


}
function validate_lname()
{
    var fn=document.getElementById("user_name").value;
    var name=(/^([a-z ,A-Z])+$/);
    if(!fn.match(name))
    {
     document.getElementById("errorln").innerHTML="Please enter a valid Last name";
     document.getElementById("user_name").value="";
     document.getElementById("user_name").focus();
 }
 else
 {
    document.getElementById("errorln").innerHTML="";
}


}
function validate_phone()
{

 var ph=document.getElementById("contact").value;

 if(ph.length<10)
 {
     document.getElementById("errorphone").innerHTML="Please enter a valid phone number";
     document.getElementById("contact").value="";
     document.getElementById("contact").focus();
 }
 else
 {
    document.getElementById("errorphone").innerHTML="";
}
}

function validateEmail(inputvalue)
{
    var pattern = /^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_.-])+\.([a-zA-Z])+([a-zA-Z])+/;
    if (pattern.test(inputvalue)) {
        document.getElementById("error-email").innerHTML = "";
    }
    else
    {
        document.getElementById("error-email").innerHTML = "Pls enter valid Email Address";
    }
}




$('#save').click(function (e)
{

    document.getElementById("save").disabled = true;

    if ($("#first_name").val() == "")
    {
//                alert("hi");
document.getElementById("errorfn").innerHTML="Please enter a valid first name";
}
else
{
    document.getElementById("errorfn").innerHTML="";
}
if ($("#last_name").val() == "")
{
 document.getElementById("errorln").innerHTML="Please enter a valid last name";
}
else
{
    document.getElementById("errorln").innerHTML="";
} 

if ($("#contact").val() == "")
{
    document.getElementById("errorphone").innerHTML="Please enter your phone number";
}
else
{
    document.getElementById("errorphone").innerHTML="";
}
if ($("#emailid").val() == "")
{
    document.getElementById("error-email").innerHTML="Please enter your email";
}
else
{
    document.getElementById("error-email").innerHTML="";
}
});
</script>
<script type="text/javascript">
  var ID = 0;
function edit_user_profile(){

    ID = document.getElementById('id').value ;
    var FN = document.getElementById('full_name').value ;
    var EID = document.getElementById('emailid').value ;
    var UN = document.getElementById('user_name').value ;
    var PW = document.getElementById('password').value ;
    var PN = document.getElementById('contact').value ;
    document.getElementById('edit_name').value =FN
    document.getElementById('edit_email').value =EID
    document.getElementById('edit_user').value =UN
    document.getElementById('edit_pass').value =PW
    document.getElementById('edit_phone').value =PN

    $("#popupbutton").click();
}
function update(){

    $("#error_message").empty();
    if ($("#edit_name").val() == '')
    {
        $("#popup_button2").click();
        $("#error_message").append("Please Fill Name Field");
        return;
    }
    else if ($('#edit_email').val() == 0)
    {
        $("#popup_button2").click();
        $("#error_message").append("Please Fill Email-id Field");
        return;
    }
    else if ($('#edit_user').val() == '')
    {
        $("#popup_button2").click();
        $("#error_message").append("Please Fill User Name Field");
        return;
    }
    else if ($('#edit_pass').val() == '')
    {
        $("#popup_button2").click();
        $("#error_message").append("Please Fill Password Field");
        return;
    }
    else if ($('#edit_phone').val() == '')
    {
        $("#popup_button2").click();
        $("#error_message").append("Please Fill Contact Field");
        return;
    }
    else 
        var id = ID;
    var e_name = document.getElementById('edit_name').value;
    var e_uname = document.getElementById('edit_user').value;
    var e_contact = document.getElementById('edit_phone').value;
    var e_email = document.getElementById('edit_email').value;
    var e_pass = document.getElementById('edit_pass').value;
    $.ajax({
     type: "POST",
     url: "<?php echo base_url(); ?>admin/editUserProfile",
     cache: false,				
     data: {id:id,e_name:e_name ,e_email:e_email,e_uname:e_uname,e_pass:e_pass,e_contact:e_contact},
     success: function(data){
        // alert(data);
        $("#terror1").hide();
        $("#message").empty();
        if (data != 0)
        {
            $("#popup_button").click();
            $("#message").append("User Edited Succesfully");
        }
        else
        {
            $("#popup_button").click();
            $("#message").append("Sorry, Something went wrong");
        }
    },
    error: function (err)
    {
        alert("Error while request");
        alert(JSON.stringify(err));
    }
});
} 
    </script>
</html>
