<!DOCTYPE html>
<html>
    <?php include('common.php'); ?>
    <head>
        <meta charset="UTF-8">
            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Test 
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="<?php echo base_url();?>dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Dashboard</li>
                    </ol>
                </section>
				<aside>
                <section class="content">

                    <div class="row">
                        <div class="col-md-12">
                            <div class="box box-primary">
                				<div class="box-header">
                                    <i class="fa fa-edit"></i>
                                    <h3 class="box-title">All</h3>
                                 </div>
                                 <br/><br/><br/><br/>
                                 <div class="box-body">
                                  		<div class="col-sm-4">
                                          Question1:
                                      	 </div>
                                          <br/><br/>
                                   </div>
                                   <div class="text-center">
                                           <img src="image/icons.png"/>
                                    </div><br/><br/>
                                     <div class="box-body">
                                                <label>
                                                <input class="uniform" type="radio" name="optionsRadios" value="option1" 							                                                    checked="checked"/>&nbsp;&nbsp;A.&nbsp;Answer
                                                </label>
                                                    <br/>
                                                <label>
                                                <input class="uniform" type="radio" name="optionsRadios" value="option1"                                                    checked="checked" />&nbsp;&nbsp;B.&nbsp;Answer
                                                </label>
                                                   <br/>
                                                <label>
                                                <input class="uniform" type="radio" name="optionsRadios" value="option1"                                                    checked="checked" />&nbsp;&nbsp;C.&nbsp;Answer
                                                </label>
                                                   <br/>
                                                <label>
                                                <input class="uniform" type="radio" name="optionsRadios" value="option1"                                                     checked="checked" />&nbsp;&nbsp;D.&nbsp;Answer
                                                 </label>
                                          
                                    </div>
                                   <div class="text-center">
                                       <button class="btn btn-primary btn-sm">Pause</button>
                                        	<img src="img/arrow-right.png"/> <img src="img/arrow-left.png"/>
                                        <button class="btn btn-primary btn-sm ">Submit</button>
                                   </div> 
                                   	
							</div>
                     	</div>
                     </div>   
                  </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->

        <!-- add new calendar event modal -->


        <!-- jQuery 2.0.2 -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
        <!-- jQuery UI 1.10.3 -->
        <script src="js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
        <!-- Bootstrap -->
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <!-- Morris.js charts -->
        <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
        <script src="js/plugins/morris/morris.min.js" type="text/javascript"></script>
        <!-- Sparkline -->
        <script src="js/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
        <!-- jvectormap -->
        <script src="js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
        <script src="js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
        <!-- jQuery Knob Chart -->
        <script src="js/plugins/jqueryKnob/jquery.knob.js" type="text/javascript"></script>
        <!-- daterangepicker -->
        <script src="js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
        <!-- datepicker -->
        <script src="js/plugins/datepicker/bootstrap-datepicker.js" type="text/javascript"></script>
        <!-- Bootstrap WYSIHTML5 -->
        <script src="js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
        <!-- iCheck -->
        <script src="js/plugins/iCheck/icheck.min.js" type="text/javascript"></script>

        <!-- AdminLTE App -->
        <script src="js/AdminLTE/app.js" type="text/javascript"></script>

        <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
        <script src="js/AdminLTE/dashboard.js" type="text/javascript"></script>

        <!-- AdminLTE for demo purposes -->
        <script src="js/AdminLTE/demo.js" type="text/javascript"></script>

    </body>
</html>