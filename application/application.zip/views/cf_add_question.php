<!DOCTYPE html>
<html>

<?php include('common.php'); ?>  
<body> 

    <!-- Right side column. Contains the navbar and content of the page -->
    <aside class="right-side">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Add Model Question
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo base_url(); ?>dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Exams</li>
                <li class="active">Add Question Set</li>
            </ol>
        </section>
        <aside>
        <section class="content-header">
                <div class="row">		
                    <div class="col-lg-12 col-md-12">				
                        <div class="row form-3">	
                            <!-- form-3-start	 -->
                            <form class="form-horizontal form-shade" id="myform" name="myform">
                              <input type="button" id="pop" name="pop" class="btn btn-primary" data-toggle="modal" data-target="#GSCChelp2" style="display:none"/>
                              <input type="text" class="form-control" id="pop_id" name="pop_id" style="display:none"/>   
                              <div class="row">
                                <div class="col-lg-7 col-md-7">
                                    <div class="row">
                                     <!-- <div class="form-group">
                                        <label for="text1" class="control-label col-lg-4">Exam</label>
                                        <div class="col-lg-8">
                                            <select class="form-control" id="exam" name="chapter" onchange="javascript:get_subject()">
                                                <option value="0">Select Exam</option>
                                                <?php
                                                $c = count($g[0]);
                                                $i = 0;
                                                while($i <$c){
                                                    echo('<option value="'.$g[0][$i]->id.'">'.$g[0][$i]->name.'</option>');
                                                    $i++;
                                                }
                                                ?>
                                            </select>						
                                        </div>
                                    </div>  -->   
                                    <div class="form-group">
                                        <label for="text1" class="control-label col-lg-4">Subject</label>
                                        <div class="col-lg-8">
                                            <select class="form-control" id="subject" name="subject" onchange="get_chapter()">
                                                <option value="0">select Subject</option>
                                                <?php
                                                $c = count($g[0]);
                                                $i = 0;
                                                while($i <$c){
                                                    echo('<option value="'.$g[0][$i]->id.'">'.$g[0][$i]->description.'</option>');
                                                    $i++;
                                                }
                                                ?>
                                            </select>						
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="text1" class="control-label col-lg-4">Chapter</label>
                                        <div class="col-lg-8">
                                            <select class="form-control" id="chapter" name="chapter" onchange="get_question_set()">
                                                <option value="0">select Chapter</option>
                                            </select>						
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="text1" class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12" >Question Type</label>
                                        <span style="color:red" id="error-question"></span>
                                        <div class="col-lg-5 col-md-8 col-sm-8 col-xs-12">
                                            <div class="custom-radio">
                                                <label class="ext-size"><input class="uniform-radiobox" type="radio" value="1" name="qtype" id="type1" />&nbsp; Test series</label>
                                                <label class="ext-size"><input class="uniform-radiobox" type="radio" value="2" name="qtype" id="type2"/>&nbsp;Assignment series</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="text1" class="control-label col-lg-4">Name</label>
                                        <div class="col-lg-8">
                                            <input type="text" placeholder="Pdf name" class="form-control" value="" id="pdf_name" name="Pdf name"/>
                                        </div>	
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-lg-4 col-md-4 col-sm-4 col-xs-12">Question File</label>
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                            <input id="q_file" type="file" style="display:none">
                                            <input id="photo_que" class="input-large form-control" onclick="$('input[id=q_file]').click();" placeholder="Browse Here" type="text">
                                        </div>
                                        <input type="button" class="btn btn-primary pull-left" id ="show_que_btn" value="Preview" onclick="vw_pdf_q();"/>
                                        <span id="err_que" style="color:red"></span>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-lg-4 col-md-4 col-sm-4 col-xs-12">Answer File</label>
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                            <input id="a_file" type="file" style="display:none">
                                            <input id="photo_ans" class="input-large form-control" onclick="$('input[id=a_file]').click();" placeholder="Browse Here" type="text">
                                        </div>
                                        <input type="button" class="btn btn-primary pull-left" id ="show_ans_btn" value="Preview" onclick="vw_pdf_a();"/>
                                        <span id="err_ans" style="color:red"></span>
                                    </div>

                                    <div class="form-group" id="save_full">
                                        <div class="col-lg-12">
                                            <a href="#" class="btn btn-primary pull-right" id="save_file" onclick="insert_file()">Upload</a>

                                        </div>	
                                    </div>
                                    <div class="form-group" style="display: none" id="sumbmit_full">
                                        <div class="col-lg-12">
                                            <a href="#" class="btn btn-primary pull-right" id="submit_file" onclick="sumit_quesSet()">Submit</a>

                                        </div>	
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-5 col-lg-5">
                              <div style="clear:both">
                                 <iframe id="viewer"  frameborder="1" scrolling="no" width="430" height="300" 
                                 style="border: solid ; color: grey;background: url(<?php echo base_url(); ?>img/synopsis.png);">
                                     
                                 </iframe>
                             </div>
                         </div>
                     </div>
                 </form>
             </div>
         </div>
     </div>
 </section><!-- /.content -->
 <section class="col-lg-12 connectedSortable">

    <div class="box-body table-responsive">
        <div id="example2_wrapper" class="dataTables_wrapper form-inline" role="grid">
            <div class="col-md-12 text-center"><h3></h3></div> 
            <div class="row"><div class="col-xs-6"></div><div class="col-xs-6"></div></div>

            <table aria-describedby="example2_info" id="example2" class="table table-bordered table-hover dataTable">

                <tbody aria-relevant="all" aria-live="polite" role="alert">                                                    
                    <tr class="odd black">
                        <td class="hide"></td>
                        <td class="text-center" style="width: 80px;">S No.</td>
                        <td class="text-center">name</td>
                        <td class="text-center">Question Path</td>
                        <td class="text-center">Answer Path</td>
                        <td class="text-center">Created on</td>
                        <!--<td class="text-center">View</td>-->
                    </tr> 

                    <?php
                    $c = count($g[1]);
                    $i = 0;
                    if ($c > 0) {
                        while ($i < $c) {
                            ?>
                            <tr class="even">												                                             
                                <td class="hide"><?php echo $g[1][$i]->id; ?></td>
                                <td class="text-center"><?php echo $i + 1; ?></td> 
                                <td class="text-left"><?php echo $g[1][$i]->name; ?></td>
                                <td class="text-left"><?php echo $g[1][$i]->question_file; ?></td>
                                <td class="text-left"><?php echo $g[1][$i]->answer_file; ?></td>
                                <td class="text-center"><?php echo $g[1][$i]->created_on; ?></td>
<!--                                                <td class="text-center">
                                                    <a href="#" onclick="edit_record('<?php //echo $g[1][$i]->id; ?>' ,
                                                                              '<?php// echo $g[1][$i]->name; ?>' ,
                                                                              '<?php //echo $g[1][$i]->question_file; ?>' ,
                                                                              '<?php //echo $g[1][$i]->answer_file; ?>');">Edit</a>
                                                                          </td>  -->

                                                                      </tr>
                                                                      <tr class="even">
                                                                      </tr>

                                                                      <?php
                                                                      $i++;
                                                                  }
                                                              } else {
                                                                echo '<tr><td colspan="4" style="color: red;">No Records Found</td></tr>';
                                                            }
                                                            ?>
                                                        </tbody></table>

                                                    </div>
                                                </div>
                                                <!--/.box-body--> 
                                                <span id="terror1" style="color: red;"></span>
                                            </form>
                                        </div>
                                    </div>

                                </div>  
                            </section>
                 <!--pop up-->
        <div id="GSCCModal4" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
        <div class="modal-content" style="margin-top:15%;">
        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;  </button>
        <h4 class="modal-title" id="myModalLabel"><b>Upload Synopsis</b></h4>
        </div>
        <div class="modal-body">
        <div class="row">
        <div class="col-lg-12">
        <div class="form-group">
            <label for="text1" class="control-label col-lg-3 col-md-3 col-sm-3 col-xs-12">Name</label>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                <input type="text" placeholder="Enter Name" class="form-control" value="" id="edit_name" name="Pdf name"/>
            </div>	
        </div>
        <div class="form-group">
        <label class="control-label col-lg-3 col-md-3 col-sm-3 col-xs-12">QFile Upload</label>
        <div class="col-lg-9  col-md-9 col-sm-9 col-xs-12">
        <input id="lefile" type="file" style="display:none">

        <div class="input-append">
        <div class="col-lg-10 col-sm-10 col-md-10 col-xs-10 custom-width">
        
        <div class="row">
            <input id="eq_file" type="file" style="display:none">
            <input id="photo_eq" class="input-large form-control" onclick="$('input[id=eq_file]').click();" placeholder="Browse Here" type="text" >
        </div>
        </div>
        <span id="err" style="color:red"></span>
        </div>
        </div>								
        </div>
        <div class="form-group">
        <label class="control-label col-lg-3 col-md-3 col-sm-3 col-xs-12">AFile Upload</label>
        <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
        <input id="lefile" type="file" style="display:none">

        <div class="input-append">
        <div class="col-lg-10 col-sm-10 col-md-10 col-xs-10 custom-width">
        
        <div class="row">
            <input id="ea_file" type="file" style="display:none">
            <!--<input id="photoCover" class="input-large form-control" onclick="$('input[id=lefile]').click();" placeholder="Browse Here" type="text">-->
            <input id="photo_ea" class="input-large form-control" onclick="$('input[id=ea_file]').click();" placeholder="Browse Here" type="text" >
        </div>
    </div>
    <div class="col-lg-2 col-xs-2">
        <div class="row">
        <!--a class="btn btn-primary" onclick="$('input[id=lefile]').click();">Browse</a-->
        <input  type="button" id="upload" value="Upload" onclick="update()"class="btn btn-primary custom-btn" />	
        </div>
        </div>
        <span id="err" style="color:red"></span>
        </div>
        </div>								
        </div>

        </div>
        </div>
        </div>
        <div class="modal-footer" style="border-top:none;">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save changes</button>-->
    </div>                              
</div>
</div>
</div> 
        <!--pop up end-->   
         <div id="popup_message" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
                    <div class="modal-dialog custom-alert">
                        <div class="modal-content" style="margin-top:20%;">
                            <div class="modal-header alert-success">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="javascript:location.href = ''">&times; </button>
                                <h4 class="modal-title" id="myModalLabel">Message</h4>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-lg-12" id="message">
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer alert-footer">
                                <a href="javascript:location.href=''" class="btn btn-success">ok</a>
                            </div>
                        </div>
                    </div>
                </div>
                 <div id="popup_error" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
                    <div class="modal-dialog custom-alert">
                        <div class="modal-content" style="margin-top:20%;">
                            <div class="modal-header alert-success">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="">&times; </button>
                                <h4 class="modal-title" id="myModalLabel">Message</h4>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-lg-12" id="error_message">
                                    </div>
                                </div>
                            </div>  
                            <div class="modal-footer alert-footer">
                                <a href="#" class="btn btn-success" data-dismiss="modal">ok</a>
                            </div>
                        </div>
                    </div>
                </div> 
                   <button class="hide" id="popupbutton" data-toggle='modal' data-target='#GSCCModal4'>Edit</button>
                   <button class="hide" id="popup_button" data-toggle="modal" data-target="#popup_message"></button>
                   <button class="hide" id="popup_button2" data-toggle="modal" data-target="#popup_error"></button>
                   
               </aside><!--//.right-side-->
           </div><!--./wrapper-->


           <!-- pop up2 -->
           <div id= "GSCChelp2" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content" style="margin-top:25%;">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times; </button>
                        <h4 class="modal-title" id="myModalLabel">Edit Question Set</h4>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <h4 class=" text-center">Are you sure to Edit Question PDF?</h4>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class=" pull-right">
                            <input type="button" class="btn btn-primary" value="YES" data-dismiss="modal" onclick="edit_questionset();"/>
                            <!--a href="javascript:addChapter();" id ="con" data-dismiss="modal" class="btn btn-primary pull-right">Add Chapter</a-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
                <!--end of popup-->  
         
                
</body>

<script type="text/javascript">
    function vw_pdf_q(){
		//alert("hi");
		 pdffile=document.getElementById("q_file").files[0];
                pdffile_url=URL.createObjectURL(pdffile);
                $('#viewer').attr('src',pdffile_url);
	}
    function vw_pdf_a(){
		//alert("hi");
		 pdffile=document.getElementById("a_file").files[0];
                pdffile_url=URL.createObjectURL(pdffile);
                $('#viewer').attr('src',pdffile_url);
	}
//    path for Question file 
    var qfile = new RegExp("(.*?)\.(pdf)$");
    $('input[id=q_file]').change(function ()
    {
        var val = $("#q_file").val();
        $("#error_message").empty();
        if (!(qfile.test(val)))
        {
            $("#popup_button2").click();
            $("#error_message").append("Invalid file format..Please upload .pdf file");
            $("#photo_que").val('');
            $('#save_file').attr("disabled", true);
        }
        else
        {
            $('#save_file').attr("disabled", false);
            $('#photo_que').val($(this).val());
            $("#err_que").empty();
        }
    });
    var eqfile = new RegExp("(.*?)\.(pdf)$");
    $('input[id=eq_file]').change(function ()
    {
        var val = $("#eq_file").val();
        $("#error_message").empty();
        if (!(eqfile.test(val)))
        {
            $("#popup_button2").click();
            $("#error_message").append("Invalid file format..Please upload .pdf file");
            $("#photo_eq").val('');
            $('#save_file').attr("disabled", true);
        }
        else
        {
            $('#save_file').attr("disabled", false);
            $('#photo_eq').val($(this).val());
            $("#err_que").empty();
        }
    });
   //    path for Answer file  
    var afile = new RegExp("(.*?)\.(pdf)$");
    $('input[id=a_file]').change(function ()
    {
        var val = $("#a_file").val();
        $("#error_message").empty();
        if (!(afile.test(val)))
        {
            $("#popup_button2").click();
            $("#error_message").append("Invalid file format..Please upload .pdf file");
            $("#photo_ans").val('');
            $('#save_file').attr("disabled", true);
        }
        else
        {
            $('#save_file').attr("disabled", false);
            $('#photo_ans').val($(this).val());
            $("#err_ans").empty();
        }
    });
    var eafile = new RegExp("(.*?)\.(pdf)$");
    $('input[id=ea_file]').change(function ()
    {
        var val = $("#ea_file").val();
        $("#error_message").empty();
        if (!(eafile.test(val)))
        {
            $("#popup_button2").click();
            $("#error_message").append("Invalid file format..Please upload .pdf file");
            $("#photo_ea").val('');
            $('#save_file').attr("disabled", true);
        }
        else
        {
            $('#save_file').attr("disabled", false);
            $('#photo_ea').val($(this).val());
            $("#err_ans").empty();
        }
    });
</script>
<script type="text/javascript">
  var g_qname=0;
  var g_aname=0;
  var q_value =0;
function insert_file()
           {
//var r_gender = $("input[name=qtype]").is(":checked");
        var data = new FormData();
            if (document.getElementById('type1').checked) {
                q_value = document.getElementById('type1').value;
//                alert(q_value);
                }
            if (document.getElementById('type2').checked) {
                q_value = document.getElementById('type2').value;
//                alert(q_value);
                }
           
        $("#error_message").empty();
        // var exam_id = $("#exam").val();
        if ($('#subject').val() == 0)
        {
            $("#popup_button2").click();
            $("#error_message").append("Please select Subject");
            return;
        }
        else if ($('#chapter').val() == 0)
        {
            $("#popup_button2").click();
            $("#error_message").append("Please select Chapter");
            return;
        }
        else if (q_value == 0)
        {
            $("#popup_button2").click();
            $("#error_message").append("Please select Question Type");
            return;
        }
        else if ($('#pdf_name').val() == '')
        {
            $("#popup_button2").click();
            $("#error_message").append("Please Fill This Name Field ");
            return;
        }
        else if ($('#q_file').val() == 0)
        {
            $("#popup_button2").click();
            $("#error_message").append("Please select Question File");
            return;
        }
        else if (!$("#a_file").val())
        {
            $("#popup_button2").click();
            $("#error_message").append("Please Select Answer File");
            return;
        }         
        else 
            // data.append('exam_id', $('#exam').val());
            data.append('subject_id', $('#subject').val());
            data.append('chapter_id', $('#chapter').val());
            data.append('que_type', q_value);
            data.append('pdf_name', $('#pdf_name').val());
            data.append('question_file', $('#q_file')[0].files[0]);
            data.append('answer_file', $('#a_file')[0].files[0]);
            $.ajax({
                type: "POST",
                url: "<?php echo base_url(); ?>admin/insertQuestionPdfFile",
                data: data,
                processData: false,
                contentType: false,
                success: function (data)
        
                {
                   alert(data);
				   console.log(data);
                    $("#terror1").hide();
                    $("#message").empty();
                    if (data != 0)
                    {
                        $("#popup_button").click();
                        $("#message").append("Pdf File Uploaded Succesfully");
                    }
                    else
                    {
                        $("#popup_button").click();
                        $("#message").append("Sorry, Something went wrong");
                    }
                },
                error: function (err)
                {
                    alert("Error while request");
                    alert(JSON.stringify(err));
                }
            });
           }
  
  function get_subject()
    {
            var exam = $('#exam').val();
//            alert(exam);
            var drpDown = document.getElementById('subject');
            drpDown.innerHTML ='';
              //alert("called");
              $.ajax({
                   type: "POST",
                   url: "<?php echo base_url();?>admin/get_cf_subject",
                   cache: false,				
                   data:{exam:exam}, 
                   success: function(data){						
//                        alert(data);
                        try{
                                if(data.length>0)
                                {
                        obj = jQuery.parseJSON(data);
//                    objdistrict = jQuery.parseJSON(data);
                    var el = document.createElement("option");
                    el.textContent = "Select Subject";
                    el.value = "0";
                    drpDown.appendChild(el);
                    for (i = 0; i < obj.length; i++)
                    {
                    var opt = obj[i]['id'];
                    var desc = obj[i]['name'];
                    var el = document.createElement("option");
                    el.textContent = desc;
                    el.value = opt;
                    drpDown.appendChild(el);
                    }
                                    
     
                           while (document.getElementById("example2").firstChild) {
                document.getElementById("example2").removeChild(document.getElementById("example2").firstChild);
                }
                document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
                    "<td class='hide'></td>"+
                    "<td class='text-center'>S No.</td>"+
                    
                    "<td class='text-center'>subject</td>"+
                    
                    "<td class='text-center'>Description</td>"+
                    
                    
                    
                    "</tr>";
                                    j=1;
                         for(i=0;i<obj.length;i++)
                         {                             
                            document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+
                            "<tr>"+
                            "<td class='hide' >"+obj[i].id+"</td>"+
                            "<td class='text-center'>"+ j +"</td>"+
                            "<td class='text-center'>"+obj[i].name+"</td>"+
                            "<td class='text-center'>"+obj[i].description+"</td>"+
                           
                           
                            "</tr>"
                            ;
                           j++;
                        }
                                }
                           else
                           {
                           document.getElementById("example2").innerHTML = "";
                           document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
                                            "<td class='hide'></td>"+
                                            "<td class='text-center'>S No.</td>"+
                                            "<td class='text-center'>subject</td>"+
                                            "<td class='text-center'>Description</td>"+

                                           
                                            
                                        "</tr>";
                                document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
                                            
                                            
                                        "<tr><td colspan='6' style='color:red;'>No Record Found</td></tr>";
                                        
                           }
                            
                           
                        }catch(e) {		
                        } 
                   },
                   
                   error: function(){						
                        //alert('Error while request..');
                   } 
                });                
                
    }  // window.onload = get_subject;
    
  function get_chapter()
    {
            var subject_id = $('#subject').val();
//            alert(exam);
            var drpDown = document.getElementById('chapter');
            drpDown.innerHTML ='';
              //alert("called");
              $.ajax({
                   type: "POST",
                   url: "<?php echo base_url();?>admin/getcf_Chapters",
                   cache: false,				
                   data:{subject_id:subject_id}, 
                   success: function(data){						
//                        alert(data);
                        try{
                         obj = jQuery.parseJSON(data);
                        if(obj.length > 0){
//                    objdistrict = jQuery.parseJSON(data);
                    var el = document.createElement("option");
                    el.textContent = "Select chapter";
                    el.value = "0";
                    drpDown.appendChild(el);
                    for (i = 0; i < obj.length; i++)
                    {
                    var opt = obj[i]['id'];
                    var desc = obj[i]['name'];
                    var el = document.createElement("option");
                    el.textContent = desc;
                    el.value = opt;
                    drpDown.appendChild(el);
                    }
                                    
     
                           while (document.getElementById("example2").firstChild) {
                document.getElementById("example2").removeChild(document.getElementById("example2").firstChild);
                }
                document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
                    "<td class='hide'></td>"+
                    "<td class='text-center'>S No.</td>"+
                    
                    "<td class='text-center'>chapter</td>"+
                    
                    "<td class='text-center'>Description</td>"+
                    
                    
                    
                    "</tr>";
                                    j=1;
                         for(i=0;i<obj.length;i++)
                         {                             
                            document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+
                            "<tr>"+
                            "<td class='hide' >"+obj[i].id+"</td>"+
                            "<td class='text-center'>"+ j +"</td>"+
                            "<td class='text-center'>"+obj[i].name+"</td>"+
                            "<td class='text-center'>"+obj[i].description+"</td>"+
                           
                           
                            "</tr>"
                            ;
                           j++;
                        }
                                }
                           else
                           {
                           document.getElementById("example2").innerHTML = "";
                           document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
                                            "<td class='hide'></td>"+
                                            "<td class='text-center'>S No.</td>"+
                                            "<td class='text-center'>chapter</td>"+
                                            "<td class='text-center'>Description</td>"+

                                           
                                            
                                        "</tr>";
                                document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
                                            
                                            
                                        "<tr><td colspan='6' style='color:red;'>No Record Found</td></tr>";
                                        
                           }
                            
                           
                        }catch(e) {		
                        } 
                   },
                   
                   error: function(){						
                        //alert('Error while request..');
                   } 
                });                
                
    }
  function get_question_set()
    {
            var chapter_id = $('#chapter').val();
              $.ajax({
                   type: "POST",
                   url: "<?php echo base_url();?>admin/get_questionSet",
                   cache: false,				
                   data:{chapter_id:chapter_id}, 
                   success: function(data){						
//                        alert(data);
                        try{
                         obj = jQuery.parseJSON(data);
                        if(obj.length > 0){
                           while (document.getElementById("example2").firstChild) {
                document.getElementById("example2").removeChild(document.getElementById("example2").firstChild);
                }
                document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
                    "<td class='hide'></td>"+
                    "<td class='text-center'>S No.</td>"+
                    "<td class='text-center'>Question File</td>"+
                    "<td class='text-center'>Answer File</td>"+
                    "<td class='text-center'>View File</td>"+
                    
                    "</tr>";
                          j=1;
                         for(i=0;i<obj.length;i++)
                         {                             
                            document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+
                            "<tr>"+
                            "<td class='hide' >"+obj[i].id+"</td>"+
                            "<td class='text-center'>"+ j +"</td>"+
                            "<td class='text-center'>"+obj[i].question_file+"</td>"+
                            "<td class='text-center'>"+obj[i].answer_file+"</td>"+
                            "<td class='text-center'>"+
                            
                            "<input type='button' class='btn btn-primary' onclick='edit_record("+obj[i].id+","+'"'+obj[i].question_file+'"'+","+'"'+obj[i].answer_file+'"'+")' value='Edit'>"+
                            "</td>"+
                            "</tr>"
                            ;
                           j++;
                        }
                                }
                           else
                           {
                           document.getElementById("example2").innerHTML = "";
                           document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
                                            "<td class='hide'></td>"+
                                            "<td class='text-center'>S No.</td>"+
                                            "<td class='text-center'>Question File</td>"+
                                            "<td class='text-center'>Answer File</td>"+
                                            "<td class='text-center'>View File</td>"+

                                        "</tr>";
                                document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
                                            
                                            
                                        "<tr><td colspan='6' style='color:red;'>No Record Found</td></tr>";
                                        
                           }
                            
                           
                        }catch(e) {		
                        } 
                   },
                   
                   error: function(){						
                        //alert('Error while request..');
                   } 
                });                
                
    }
   
     function edit_record(id,qname,aname)
    {
        g_qname=qname;
        g_aname= aname;
        document.getElementById('pop_id').value=id;
        $("#popupbutton").click();
    }
    function update(){
        var data = new FormData();
        $("#error_message").empty();
        if ($('#edit_name').val() == '')
        {
            $("#popup_button2").click();
            $("#error_message").append("Please fill name field");
            return;
        }
        else if ($('#eq_file').val() == 0)
        {
            $("#popup_button2").click();
            $("#error_message").append("Please select Question File");
            return;
        }
        else if (!$("#ea_file").val())
        {
            $("#popup_button2").click();
            $("#error_message").append("Please Select Answer File");
            return;
        }         
        else 
            data.append('id', $('#pop_id').val());
            data.append('exam_id', $('#exam').val());
            data.append('subject_id', $('#subject').val());
            data.append('chapter_id', $('#chapter').val());
            data.append('ques_name', $('#edit_name').val());
            data.append('oldquestion_file', g_qname);
            data.append('oldanswer_file', g_aname);
            data.append('newquestion_file', $('#eq_file')[0].files[0]);
            data.append('newanswer_file', $('#ea_file')[0].files[0]);
            $.ajax({
                type: "POST",
                url: "<?php echo base_url(); ?>admin/editQuestionPdfFile",
//                beforeSend: function () {
//                    document.getElementById('terror1').innerHTML = "<center>Uploading.. Please wait..</center>";
//                    $('#terror1').prepend('<center><img class="inline" src="<?php echo base_url(); ?>img/ajax-loader.gif" /></center>');
//                },
                data: data,
                processData: false,
                contentType: false,
                success: function (data)
        
                {
                   alert(data);
				   console.log(data);
                    $("#terror1").hide();
                    $("#message").empty();
                    if (data != 0)
                    {
                        $("#popup_button").click();
                        $("#message").append("Pdf File Edited Succesfully");
                    }
                    else
                    {
                        $("#popup_button").click();
                        $("#message").append("Sorry, Something went wrong");
                    }
                },
                error: function (err)
                {
                    alert("Error while request");
                    alert(JSON.stringify(err));
                }
            });
    }
</script>
</html>



