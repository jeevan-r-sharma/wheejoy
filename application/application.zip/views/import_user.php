<!DOCTYPE html>
<html>

<?php include('common.php'); ?>    
<style type="text/css">
    .tr  {
        text-align: center;
    }
</style>
<body> 


    <!-- Right side column. Contains the navbar and content of the page -->
    <aside class="right-side">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Import User Details
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo base_url(); ?>dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
                <!--                        <li>Refer A Friend</li>-->

                <li class="active">Import User Details</li>
            </ol>
        </section>
        <aside>
        <section class="content-header">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="row form-3">
                        <!-- <h5 class="form-title">Import User Details</h5> -->
                        <!-- form-3-start -->
                    <form class="form-horizontal form-shade" id="myform" name="myform" method="post" action="<?php echo base_url(); ?>import/getTxtdata">
                            <div class="form-group" id="exam_full">
                                <label for="text1" class="control-label col-lg-4">Select Subscription</label>
                                <div class="col-lg-5"  style="padding-right: 60px;">
                                    <select class="form-control" id="exam" name="exam">
                                        <option value="0">Select Subscription</option>
                                        <?php
                                        $c = count($g[0]);
                                        $i = 0;
                                        while($i <$c){
                                            echo('<option value="'.$g[0][$i]->id.'">'.$g[0][$i]->name.'</option>');
                                            $i++;
                                        }
                                        ?>
                                    </select>                       
                                </div>
                            </div> 

                            <div class="form-group">
                                <label class="control-label col-lg-4">File Upload</label>
                                <div class="col-lg-6 col-md-6 col-sm-8 col-xs-12">
                                    <input id="lefile" type="file" style="display: none;">
                                    <div class="col-sm-9 col-xs-12">
                                        <input id="lefile_upload" type="file" style="display: none;">
                                        <div class="input-append">
                                            <div class="col-lg-10 col-sm-10 col-md-10 col-xs-10 custom-width">
                                                <div class="row">
                                                    <input id="photoCover" class="input-large form-control" onclick="$('input[id=lefile_upload]').click();" placeholder="Browse Here" type="text" style="    margin-left: -14px;">
                                                </div>
                                                <span id="err_que" style="color:red"></span>
                                            </div>
                                            <div class="col-lg-2 col-xs-2">
                                                <div class="row">
                                                    <input type="button" id="upload1" value="Upload" class="btn btn-primary custon-btn"  />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group" id="submitFull" style="display: none;">
                            <div class="col-lg-5 pull-right">
                                <input type="button" id="submit" onclick="javascript:ImportSubmit();" value="Submit" class="btn btn-primary custon-btn" style="    margin-left: 42px;" />
                             </div>   
                            </div>
                        </form>                      
                        </div>

                </div>
              </div>
        </section>
   
                    
                    <div class="clearfix">&nbsp;</div>
                    <section class="col-lg-12 connectedSortable">
                    <div id="detailstable" name="tab" style="display:none;" class="box-body table-responsive">
                    <span id="terror1" name="terror1" style="color:red;"></span>
                        <div id="example2_wrapper" class="dataTables_wrapper form-inline" role="grid">
                        
                        <div class="col-md-12 text-center"><h3>Student Details </h3></div>
                            <div class="row"><div class="col-xs-6"></div><div class="col-xs-6"></div></div>
                            <table aria-describedby="example2_info" id="example3" class="table table-bordered table-hover dataTable">
                                <!--<tbody aria-relevant="all" aria-live="polite" role="alert"><tr class="odd black">-->
                                <!-- <thead aria-relevant="all" aria-live="polite" role="alert"> -->
                                <tr class="odd black">
                                    <td class="text-center">SR NO</td>
                                    <td class="text-center">First Name</td>
                                    <td class="text-center">Last Name</td>
                                    <td class="text-center">Gender</td>
                                    <td class="text-center">Phone</td>
                                    <td class="text-center">Email ID</td>
                                    <td class="text-center">City</td>
                                    <td class="text-center">College Name</td>
                                </tr>
                                <!-- </thead> -->
                                <!--</tbody>-->
                            </table>
                            <div id="container5"></div>
                        </div>
                    </div><!-- /.box-body -->
                    </section>
                    <div id="popup_error" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
                    <div class="modal-dialog custom-alert">
                        <div class="modal-content" style="margin-top:20%;">
                            <div class="modal-header alert-success">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="">&times; </button>
                                <h4 class="modal-title" id="myModalLabel">Message</h4>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-lg-12" id="error_message">
                                    </div>
                                </div>
                            </div>  
                            <div class="modal-footer alert-footer">
                                <a href="#" class="btn btn-success" data-dismiss="modal">ok</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="popup_message" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
                    <div class="modal-dialog custom-alert">
                        <div class="modal-content" style="margin-top:20%;">
                            <div class="modal-header alert-success">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="javascript:location.href = ''">&times; </button>
                                <h4 class="modal-title" id="myModalLabel">Message</h4>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-lg-12" id="message">
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer alert-footer">
                                <a href="javascript:location.href=''" class="btn btn-success">ok</a>
                            </div>
                        </div>
                    </div>
                </div>
                    <button class="hide" id="popup_button" data-toggle="modal" data-target="#popup_message"></button> 
                    <button class="hide" id="popup_button2" data-toggle="modal" data-target="#popup_error"></button>
    </aside><!-- /.right-side -->
</body>
<script type="text/javascript">
 
var obj = [];
$("#upload1").click(function () {
        var exam_id = $("#exam").val();
        var file_data = $("#lefile_upload").prop("files")[0];
        var file = $("#photoCover").val();
        var regex = new RegExp("(.*?)\.(xls)$");
            $("#error_message").empty();

        if (exam_id == 0)
        {
            $("#popup_button2").click();
            $("#error_message").append("Please Select Exam.");   
            return;
        }else if(file == 0){
            $("#popup_button2").click();
            $("#error_message").append("Please Upload File.");
            return;  
        }else if (!(regex.test(file)))
        {
            $("#popup_button2").click();
            $("#error_message").append("Invalid File!!!! Please upload .xls files only");
            $("#photoCover").val() = "";
            return;
        }else {
            var form_data = new FormData();
            form_data.append("file", file_data);
            form_data.append("exam", exam_id);
                $.ajax({
                url: "<?php echo base_url(); ?>admin/getExcelDatastu",
                dataType: 'text',
                cache: false,
                contentType: false,
                processData: false,
                data: form_data,
                type: 'post',
                success: function (data) {
                //alert(data);

                obj = jQuery.parseJSON(data);
                if ((obj['0'].length < 100) && (obj['1'] >= 7))
                {
                $("#detailstable").show();
                $("#submitFull").show();
                $("#example2_wrapper").find("tr:gt(0)").remove();
                var table = document.getElementById("example3");
                var j = 1;
                for (var i = 0; i < obj['0'].length; i++)
                {
                document.getElementById("example3").innerHTML = document.getElementById("example3").innerHTML +
                         "<tr>" +
                                                "<td class='text-center'>" + j + "</td>" +
                                                "<td class='text-center'>" + obj['0'][i]['A'] + "</td>" +
                                                "<td class='text-center'>" + obj['0'][i]['B'] + "</td>" +
                                                "<td class='text-center'>" + obj['0'][i]['C'] + "</td>" +
                                                "<td class='text-center'>" + obj['0'][i]['D'] + "</td>" +
                                                "<td class='text-center'>" + obj['0'][i]['E'] + "</td>" +
                                                "<td class='text-center'>" + obj['0'][i]['F'] + "</td>" +
                                                "<td class='text-center'>" + obj['0'][i]['G'] + "</td>" +
                          "</tr>"
                           ;
                           j++;            
                          }
                        }
                else {
                    $("#popup_button2").click();
                    $("#error_message").append("please check the number of columns(7)");
                    $("#photoCover").val() = "";
                }
            }
        });
    }
});
function ImportSubmit(){
    var exam_id = $("#exam").val();
    $("#error_message").empty();

    if (exam_id == 0){
        $("#popup_button2").click();
        $("#error_message").append("Please Select Exam plan");
        return;
    }else if (obj.length == 0){
        $("#popup_button2").click();
        $("#error_message").append("Please Select file");
        return;
    }else {
            var TableData = new Array();
            $('#example3 tr').each(function(row, tr) {
                TableData[row] = {
                    "f_name": $(tr).find('td:eq(1)').text()
                    , "l_name": $(tr).find('td:eq(2)').text()
                    , "gender": $(tr).find('td:eq(3)').text()
                    , "phone": $(tr).find('td:eq(4)').text()
                    , "email": $(tr).find('td:eq(5)').text()
                    , "city": $(tr).find('td:eq(6)').text()
                    , "college": $(tr).find('td:eq(7)').text()
                }
            });
            TableData.shift();
            var tabledata1 = JSON.stringify(TableData);
                       // alert(tabledata1);
            var table2 = JSON.parse(tabledata1);
                          // alert(table2);
            $.ajax({
                type: "POST",
                url: "<?php echo base_url(); ?>admin/import_student",
                async: true,
                timeout: 500000,
                beforeSend: function () {
                document.getElementById('terror1').innerHTML = "<center>Processing.. Please wait. It May Take Few minutes</center>";
                $('#example2_wrapper').hide();
                $('#terror1').prepend('<center><img class="inline" src="<?php echo base_url(); ?>img/ajax-loader.gif" /></center>');
                },
                data: {exam_id: exam_id, student_records:table2},
                success: function (data)
                {
                                    // alert(data);
                                    // console.log(data);
                    $('#terror1').hide();
                    if (data != 0)
                    {
                        $("#popup_button").click();
                        $("#message").append("Import Successfull");
                    }
                    // else if (data == 'user already exits')
                    // {
                        // $("#popup_button").click();
                        // $("#message").append("Sorry, user already exits");
                    // }
					else {
						$("#popup_button").click();
                        $("#message").append("Sorry, somthing went Wrong");
					}
                },
                error: function (e) {
                    alert(JSON.stringify(e));
                    alert("Error while request");
                }
            });
    }

}
</script>
<script type="text/javascript">
    $('input[id=lefile]').change(function ()
    {
    $('#photoCover').val($(this).val());
    });

    var qfile = new RegExp("(.*?)\.(xls)$");
    $('input[id=lefile_upload]').change(function ()
    {
        var val = $("#lefile_upload").val();
        $("#error_message").empty();
        if (!(qfile.test(val)))
        {
            $("#popup_button2").click();
            $("#error_message").append("Invalid file format..Please upload .xls file");
            $("#photoCover").val('');
        }
        else
        {
            $('#save_file').attr("disabled", false);
            $('#photoCover').val($(this).val());
            $("#err_que").empty();
        }
    });
    </script>
<script type="text/css">
    div#spinner
    {
    display: none;
    width:100px;
    height: 100px;
    position: fixed;
    top: 50%;
    left: 50%;
    background:url(img/ajax-loader.gif) no-repeat center #fff;
    text-align:center;
    padding:10px;
    font:normal 16px Tahoma, Geneva, sans-serif;
    border:1px solid #666;
    margin-left: -50px;
    margin-top: -50px;
    z-index:2;
    overflow: auto;
    }
    </script>
    <style>
    #container5 {
    margin: 0 auto;
    padding: 5px;
    }
    .pagination {
    margin:0;
    }

    .page {
    display: inline-block;
    padding: 0px 9px;
    margin:0 4px 4px 0;
    border-radius: 3px;
    border: solid 1px #c0c0c0;
    background: #e9e9e9;
    box-shadow: inset 0px 1px 0px rgba(255,255,255, .8), 0px 1px 3px rgba(0,0,0, .1);
    font-size: 1.2em;
    font-weight: bold;
    text-decoration: none;
    color: #717171;
    text-shadow: 0px 1px 0px rgba(255,255,255, 1);
    }

    .page:hover, .page.gradient:hover {
    background: #fefefe;
    background: -webkit-gradient(linear, 0% 0%, 0% 100%, from(#FEFEFE), to(#f0f0f0));
    background: -moz-linear-gradient(0% 0% 270deg,#FEFEFE, #f0f0f0);
    }

    .page.active {
    border: none;
    background: #6CA9D5;
    box-shadow: inset 0px 0px 8px rgba(0,0,0, .5), 0px 1px 0px rgba(255,255,255, .8);
    color: #f0f0f0;
    text-shadow: 0px 0px 3px rgba(0,0,0, .5);
    }

    </style>
</html>



