<!DOCTYPE html>
<html>

<?php include('common.php'); ?>  
<body> 

    <!-- Right side column. Contains the navbar and content of the page -->
    <aside class="right-side">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Add Video
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo base_url(); ?>dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
                <!--                        <li>Refer A Friend</li>-->

                <li class="active">Add Video</li>
            </ol>
        </section>
        <section class="content-header">
            <div class="row">		
                <div class="col-lg-12 col-md-12">				
                    <div class="row form-3">	
                        <!--form-3-start-->	
                        <form class="form-horizontal " id="myform" name="myform">
                          <input type="button" id="pop" name="pop" class="btn btn-primary" data-toggle="modal" data-target="#GSCChelp2" style="display:none"/>
                          <input type="text" class="form-control" id="pop_id" name="pop_id" style="display:none"/>   
                          <div class="col-lg-6 col-md-6">
                           <div class="row">
                               <!-- <div class="form-group" id="exam_full">
                                <label for="text1" class="control-label col-lg-4">Exam Name</label>
                                <div class="col-lg-8">
                                    <select class="form-control" id="exam" name="exam" onchange="javascript:get_subject()">
                                        <option value="0">Select Exam</option>
                                        <?php
                                        $c = count($g[0]);
                                        $i = 0;
                                        while($i <$c){
                                            echo('<option value="'.$g[0][$i]->id.'">'.$g[0][$i]->name.'</option>');
                                            $i++;
                                        }
                                        ?>
                                    </select>						
                                </div>
                            </div>  -->       
                            <div class="form-group" id="subject_full">
                                <label for="text1" class="control-label col-lg-4">Subject</label>
                                <div class="col-lg-8">
                                    <select class="form-control" id="subject" name="subject" onchange="javascript:get_chapter()">
                                        <option value="0">Select Subject</option>
                                        <?php
                                        $c = count($g[0]);
                                        $i = 0;
                                        while($i <$c){
                                            echo('<option value="'.$g[0][$i]->id.'">'.$g[0][$i]->description.'</option>');
                                            $i++;
                                        }
                                        ?>
                                    </select>						
                                </div>
                            </div>
                            
                            <div class="form-group" id="chapter_full">
                                <label for="text1" class="control-label col-lg-4">Chapter</label>
                                <div class="col-lg-8">
                                    <select class="form-control" id="chapter" name="chapter" onchange="javascript:get_topic()">
                                        <option value="0">select Chapter</option>
                                    </select>						
                                </div>
                            </div>
                            <div class="form-group" id="topic_full">
                                <label for="text1" class="control-label col-lg-4">Topic</label>
                                <div class="col-lg-8">
                                    <select class="form-control" id="topic" name="topic" onchange="javascript:get_video_list()">
                                        <option value="0">select Topic</option>
                                    </select>						
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="text1" class="control-label col-lg-4">Name</label>
                                <div class="col-lg-8">
                                    <input type="text" placeholder="Enter video Name" class="form-control" value="" id="name" name="video name"/>
                                </div>	
                            </div>
                            <div class="form-group">
                                <label for="text1" class="control-label col-lg-4">Description</label>
                                <div class="col-lg-8">
                                    <input type="text" placeholder="Enter video Description" class="form-control" value="" id="description" name="description"/>
                                </div>	
                            </div>
                            <div class="form-group">
                                <label for="text1" class="control-label col-lg-4">Video Link</label>
                                <div class="col-lg-8">
                                    <input type="text" placeholder="Enter Video Link" class="form-control" value="" id="v_link" name="Video Link" onblur=""/>
                                </div>	
                            </div>
                            <div class="form-group">
                                <label for="text1" class="control-label col-lg-4">Source Link</label>
                                <div class="col-lg-8">
                                    <input type="text" placeholder="Enter offline Name" class="form-control" value="" id="o_link" name=""/>
                                </div>	
                            </div>
                            <div class="form-group">
                                <label for="text1" class="control-label col-lg-4">Duration</label>
                                <div class="col-lg-8">
                                    <input type="text" placeholder="Enter Duration" class="form-control" value="" id="duration" name="Duration"/>
                                </div>	
                            </div>
                            <div class="form-group" id="add_full">
                                <div class="col-lg-12">
                                    <a href="#" class="btn btn-primary pull-right" id="add" onclick="javascript:call_offline()">Add</a>

                                </div>	
                            </div>
                            <div class="form-group" id="submit_full" style="display: none">
                                <div class="col-lg-12">
                                    <a href="#" class="btn btn-primary pull-right" id="add" onclick="javascript:submit_edited()">submit</a>

                                </div>	
                            </div>
                        </div>               
                    </div>
                    <div class="col-lg-6 col-md-6" id="player" >    
                        <iframe src="" style="border: solid ; color: grey;background: url(<?php echo base_url(); ?>img/vimeo_player.png);" id="play" width="520" height="321" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>    
                    </div> 
                    <input class="btn btn-primary pull-right" type="button" value="Play" onclick="call_video_link()" />
                </form>
            </div>
        </div>
    </div>
</section><!-- /.content -->
<section class="col-lg-12 connectedSortable">
    
    <div class="box-body table-responsive">
        <div id="example2_wrapper" class="dataTables_wrapper form-inline" role="grid">
            <div class="col-md-12 text-center"><h3></h3></div> 
            <div class="row"><div class="col-xs-6"></div><div class="col-xs-6"></div></div>
            
            <table aria-describedby="example2_info" id="example2" class="table table-bordered table-hover dataTable">
                
                <tbody aria-relevant="all" aria-live="polite" role="alert">                                                    
                    <tr class="odd black">
                        <td class="hide"></td>
                        <td class="text-center" style="width: 80px;">S No.</td>
                        <td class="text-center">video name</td>
                        <td class="text-center">description</td>
                        <td class="text-center">video file</td>
                        <td class="text-center">source file</td>
                        <td class="text-center">is_video_link</td>
                        <td class="text-center">duration</td>
                        <td class="text-center">View</td>
                    </tr> 
                    
                    <?php
                    $c = count($g[1]);
                    $i = 0;
                    if ($c > 0) {
                        while ($i < $c) {
                            ?>
                            <tr class="even">												                                             
                                <td class="hide"><?php echo $g[1][$i]->id; ?></td>
                                <td class="text-center"><?php echo $i + 1; ?></td> 
                                <td class="text-center"><?php echo $g[1][$i]->name; ?></td>
                                <td class="text-center"><?php echo $g[1][$i]->description; ?></td>
                                <td class="text-center"><?php echo $g[1][$i]->video_file; ?></td>
                                <td class="text-center"><?php echo $g[1][$i]->source_file; ?></td>
                                <td class="text-center"><?php echo $g[1][$i]->is_video_link; ?></td>
                                <td class="text-center"><?php echo $g[1][$i]->duration; ?></td>
                                <td class="text-center">
                                    <a href="#" class="btn btn-primary" onclick="edit_record('<?php echo $g[1][$i]->id; ?>' , 
                                       '<?php echo $g[1][$i]->name; ?>' ,
                                       '<?php echo $g[1][$i]->description; ?>' ,
                                       '<?php echo $g[1][$i]->video_file; ?>' ,
                                       '<?php echo $g[1][$i]->duration; ?>' ,
                                       '<?php echo $g[1][$i]->source_file; ?>');">Edit</a>
                                   </td>  
                                   
                               </tr>
                               <tr class="even">
                               </tr>
                               
                               <?php
                               $i++;
                           }
                       } else {
                        echo '<tr><td colspan="4" style="color: red;">No Records Found</td></tr>';
                    }
                    ?>
                </tbody></table>
                
            </div>
        </div><!-- /.box-body -->
        
    </form>
</div>
</div>

</div>  
</section><!-- /.content -->
<div id="popup_message" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog custom-alert">
        <div class="modal-content" style="margin-top:20%;">
            <div class="modal-header alert-success">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="javascript:location.href = ''">&times; </button>
                <h4 class="modal-title" id="myModalLabel">Message</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12" id="message">
                    </div>
                </div>
            </div>
            <div class="modal-footer alert-footer">
                <a href="javascript:location.href=''" class="btn btn-success">ok</a>
            </div>
        </div>
    </div>
</div>
<div id="popup_error" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog custom-alert">
        <div class="modal-content" style="margin-top:20%;">
            <div class="modal-header alert-success">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="">&times; </button>
                <h4 class="modal-title" id="myModalLabel">Message</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12" id="error_message">
                    </div>
                </div>
            </div>  
            <div class="modal-footer alert-footer">
                <a href="#" class="btn btn-success" data-dismiss="modal">ok</a>
            </div>
        </div>
    </div>
</div>  
<button class="hide" id="popup_button" data-toggle="modal" data-target="#popup_message"></button>
<button class="hide" id="popup_button2" data-toggle="modal" data-target="#popup_error"></button>
<button class="hide" id="popup_button3" data-toggle="modal" data-target="#GSCChelp3"></button>
</aside><!-- /.right-side -->
</div><!-- ./wrapper -->


<!--pop up2-->
<div id= "GSCChelp2" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content" style="margin-top:25%;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times; </button>
                <h4 class="modal-title" id="myModalLabel">Edit Video</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <h4 class=" text-center">Are you sure to Edit Video?</h4>
                </div>
            </div>
            <div class="modal-footer">
                <div class=" pull-right">
                    <input type="button" class="btn btn-primary" value="YES" data-dismiss="modal" onclick="edit_video();"/>
                    <!--a href="javascript:addChapter();" id ="con" data-dismiss="modal" class="btn btn-primary pull-right">Add Chapter</a-->
                </div>
            </div>
        </div>
    </div>
</div>
<!--end of popup-->  
<!--pop up3-->
<div id= "GSCChelp3" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content" style="margin-top:25%;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times; </button>
                <h4 class="modal-title" id="myModalLabel">Offline Video</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <h4 class=" text-center">Are you sure with out offline link you want to submit?</h4>
                </div>
            </div>
            <div class="modal-footer">
                <div class=" pull-right">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    <input type="button" class="btn btn-primary" value="YES" data-dismiss="modal" onclick="insert_video();"/>
                    <!--a href="javascript:addChapter();" id ="con" data-dismiss="modal" class="btn btn-primary pull-right">Add Chapter</a-->
                </div>
            </div>
        </div>
    </div>
</div>
<!--end of popup-->  






</body>

<script type="text/javascript">
function call_video_link(){
       // alert("hi");
    if($("#v_link").val() == '')   {
        alert('Please Enter Video Link')
    }else{
        var vlink1 = document.getElementById('v_link').value;
        vlinksplit= vlink1.split('vimeo.com/');
        vlinksplit1= vlinksplit[0];
        vlinksplit2= vlinksplit[1];
        vlinksplit3= vlinksplit2.split('/');
        vlink= vlinksplit3[0];
        play.src = "https://player.vimeo.com/video/"+vlink ;
    }
        //          play.src = vlink ;
}
function call_offline(){
//        alert('hi');
if($("#o_link").val() == ''){
  $("#popup_button3").click();  
}else{
  insert_video();  
}

}
function insert_video(){
//        var data = new FormData();
$("#error_message").empty();
if ($("#exam").val() == 0)
{
    $("#popup_button2").click();
    $("#error_message").append("Please select Exam");
    return;
}
else if ($('#subject').val() == 0)
{
    $("#popup_button2").click();
    $("#error_message").append("Please select Subject");
    return;
}
else if ($('#chapter').val() == 0)
{
    $("#popup_button2").click();
    $("#error_message").append("Please select Chapter");
    return;
}
else if ($('#topic').val() == 0)
{
    $("#popup_button2").click();
    $("#error_message").append("Please select Topic");
    return;
}
else if ($('#name').val() == '')
{
    $("#popup_button2").click();
    $("#error_message").append("Please Fill Name Field ");
    return;
}
else if ($('#description').val() == '')
{
    $("#popup_button2").click();
    $("#error_message").append("Please Fill Description Field ");
    return;
}
else if ($('#v_link').val() == '')
{
    $("#popup_button2").click();
    $("#error_message").append("Please Fill Video Field ");
    return;
}
else if ($('#duration').val() == '')
{
    $("#popup_button2").click();
    $("#error_message").append("Please Fill This Field ");
    return;
}

else 
    var topic_id = document.getElementById('topic').value;
var video_name= document.getElementById('name').value;
var video_desc= document.getElementById('description').value;
var video_link= document.getElementById('v_link').value;
var off_link= document.getElementById('o_link').value;
var duration= document.getElementById('duration').value;
//        alert(topic_id);alert(video_name);alert(video_desc);alert(video_link);alert(duration);
$.ajax({
    type: "POST",
    url: "<?php echo base_url(); ?>admin/insertVideoFile",
    data: {topic_id:topic_id,video_name:video_name,video_desc:video_desc,video_link:video_link,off_link:off_link,duration:duration},
    cache: false,
    success: function (data)
    
    {
//                    alert(data);
$("#terror1").hide();
$("#message").empty();
if (data != 0)
{
    $("#popup_button").click();
    $("#message").append("Video File Uploaded Succesfully");
}
else
{
    $("#popup_button").click();
    $("#message").append("Sorry, Something went wrong");
}
},
error: function (err)
{
    alert("Error while request");
    alert(JSON.stringify(err));
}
});

}
function get_subject()
{
    var exam = $('#exam').val();
    var drpDown = document.getElementById('subject');
    drpDown.innerHTML ='';
    $.ajax({
     type: "POST",
     url: "<?php echo base_url();?>admin/get_cf_subject",
     cache: false,				
     data:{exam:exam}, 
     success: function(data){						
//                        alert(data);
try{
   if(data.length>0)
   {
    obj = jQuery.parseJSON(data);
    var el = document.createElement("option");
    el.textContent = "Select Subject";
    el.value = "0";
    drpDown.appendChild(el);
    for (i = 0; i < obj.length; i++)
    {
        var opt = obj[i]['id'];
        var desc = obj[i]['name'];
        var el = document.createElement("option");
        el.textContent = desc;
        el.value = opt;
        drpDown.appendChild(el);
    }
    while (document.getElementById("example2").firstChild) {
        document.getElementById("example2").removeChild(document.getElementById("example2").firstChild);
    }
    document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
    "<td class='hide'></td>"+
    "<td class='text-center'>S No.</td>"+
    
    "<td class='text-center'>subject</td>"+
    
    "<td class='text-center'>Description</td>"+
    
    "</tr>";
    j=1;
    for(i=0;i<obj.length;i++)
    {                             
        document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+
        "<tr>"+
        "<td class='hide' >"+obj[i].id+"</td>"+
        "<td class='text-center'>"+ j +"</td>"+
        "<td class='text-center'>"+obj[i].name+"</td>"+
        "<td class='text-center'>"+obj[i].description+"</td>"+
        
        "</tr>"
        ;
        j++;
    }
}
else
{
 document.getElementById("example2").innerHTML = "";
 document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
 "<td class='hide'></td>"+
 "<td class='text-center'>S No.</td>"+
 "<td class='text-center'>subject</td>"+
 "<td class='text-center'>Description</td>"+

 "</tr>";
 document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
 
 "<tr><td colspan='6' style='color:red;'>No Record Found</td></tr>";
 
}
}catch(e) {		
} 
},

error: function(){						
    alert('Error while request..');
} 
});                
    
}

function get_chapter()
{
    var subject_id = $('#subject').val();
    var drpDown = document.getElementById('chapter');
    drpDown.innerHTML ='';
    $.ajax({
     type: "POST",
     url: "<?php echo base_url();?>admin/getcf_Chapters",
     cache: false,				
     data:{subject_id:subject_id}, 
     success: function(data){						
//                        alert(data);
try{
   obj = jQuery.parseJSON(data);
   if(obj.length > 0){
    var el = document.createElement("option");
    el.textContent = "Select chapter";
    el.value = "0";
    drpDown.appendChild(el);
    for (i = 0; i < obj.length; i++)
    {
        var opt = obj[i]['id'];
        var desc = obj[i]['name'];
        var el = document.createElement("option");
        el.textContent = desc;
        el.value = opt;
        drpDown.appendChild(el);
    }
    
    
    while (document.getElementById("example2").firstChild) {
        document.getElementById("example2").removeChild(document.getElementById("example2").firstChild);
    }
    document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
    "<td class='hide'></td>"+
    "<td class='text-center'>S No.</td>"+
    
    "<td class='text-center'>chapter</td>"+
    
    "<td class='text-center'>Description</td>"+
    
    
    
    "</tr>";
    j=1;
    for(i=0;i<obj.length;i++)
    {                             
        document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+
        "<tr>"+
        "<td class='hide' >"+obj[i].id+"</td>"+
        "<td class='text-center'>"+ j +"</td>"+
        "<td class='text-center'>"+obj[i].name+"</td>"+
        "<td class='text-center'>"+obj[i].description+"</td>"+
        
        
        "</tr>"
        ;
        j++;
    }
}
else
{
 document.getElementById("example2").innerHTML = "";
 document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
 "<td class='hide'></td>"+
 "<td class='text-center'>S No.</td>"+
 "<td class='text-center'>chapter</td>"+
 "<td class='text-center'>Description</td>"+

 
 
 "</tr>";
 document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
 
 
 "<tr><td colspan='6' style='color:red;'>No Record Found</td></tr>";
 
}


}catch(e) {		
} 
},

error: function(){						
    alert('Error while request..');
} 
});                
}

function get_topic()
{
    var chapter_id = $('#chapter').val();
    var drpDown = document.getElementById('topic');
    drpDown.innerHTML ='';
    $.ajax({
     type: "POST",
     url: "<?php echo base_url();?>admin/get_cf_topics",
     cache: false,				
     data:{chapter_id:chapter_id}, 
     success: function(data){						
//                        alert(data);
try{
    obj = jQuery.parseJSON(data);
    if(obj.length > 0){
        var el = document.createElement("option");
        el.textContent = "Select Topic";
        el.value = "0";
        drpDown.appendChild(el);
        for (i = 0; i < obj.length; i++)
        {
            var opt = obj[i]['id'];
            var desc = obj[i]['name'];
            var el = document.createElement("option");
            el.textContent = desc;
            el.value = opt;
            drpDown.appendChild(el);
        }
        while (document.getElementById("example2").firstChild) {
            document.getElementById("example2").removeChild(document.getElementById("example2").firstChild);
        }
        document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
        "<td class='hide'></td>"+
        "<td class='text-center'>S No.</td>"+
        
        "<td class='text-center'>topic</td>"+
        
        "<td class='text-center'>Description</td>"+
        
        
        
        "</tr>";
        j=1;
        for(i=0;i<obj.length;i++)
        {                             
            document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+
            "<tr>"+
            "<td class='hide' >"+obj[i].id+"</td>"+
            "<td class='text-center'>"+ j +"</td>"+
            "<td class='text-center'>"+obj[i].name+"</td>"+
            "<td class='text-center'>"+obj[i].description+"</td>"+
            
            
            "</tr>"
            ;
            j++;
        }
    }
    else
    {
     document.getElementById("example2").innerHTML = "";
     document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
     "<td class='hide'></td>"+
     "<td class='text-center'>S No.</td>"+
     "<td class='text-center'>topic</td>"+
     "<td class='text-center'>Description</td>"+

     
     
     "</tr>";
     document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
     
     
     "<tr><td colspan='6' style='color:red;'>No Record Found</td></tr>";
     
 }
 
 
}catch(e) {		
} 
},

error: function(){						
    alert('Error while request..');
} 
});                
    
} 
function get_video_list()
{
    var topic_id = $('#topic').val();
//            alert(topic_id);
$.ajax({
 type: "POST",
 url: "<?php echo base_url();?>admin/get_video_list",
 cache: false,				
 data:{topic_id:topic_id}, 
 success: function(data){						
//                        alert(data);
try{
   obj = jQuery.parseJSON(data);
   if(obj.length > 0){
     while (document.getElementById("example2").firstChild) {
        document.getElementById("example2").removeChild(document.getElementById("example2").firstChild);
    }
    document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
    "<td class='hide'></td>"+
    "<td class='text-center'>S No.</td>"+
    "<td class='text-center'>video name</td>"+
    "<td class='text-center'>description</td>"+
    "<td class='text-center'>video Path</td>"+
    "<td class='text-center'>is_video_link</td>"+
    "<td class='text-center'>duration</td>"+
    
    "</tr>";
    j=1;
    for(i=0;i<obj.length;i++)
    {                             
        document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+
        "<tr>"+
        "<td class='hide' >"+obj[i].id+"</td>"+
        "<td class='text-center'>"+ j +"</td>"+
        "<td class='text-center'>"+obj[i].name+"</td>"+
        "<td class='text-center'>"+obj[i].description+"</td>"+
        "<td class='text-center'>"+obj[i].video_file+"</td>"+
        "<td class='text-center'>"+obj[i].is_video_link+"</td>"+
        "<td class='text-center'>"+obj[i].duration+"</td>"+
        
        
        "</tr>"
        ;
        j++;
    }
}
else
{
 document.getElementById("example2").innerHTML = "";
 document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
 "<td class='hide'></td>"+
 "<td class='text-center'>S No.</td>"+
 "<td class='text-center'>video name</td>"+
 "<td class='text-center'>description</td>"+
 "<td class='text-center'>video Path</td>"+
 "<td class='text-center'>is_video_link</td>"+
 "<td class='text-center'>duration</td>"+

 "</tr>";
 document.getElementById("example2").innerHTML = document.getElementById("example2").innerHTML+"<tr class='odd black'>"+
 
 
 "<tr><td colspan='7' style='color:red;'>No Record Found</td></tr>";
 
}


}catch(e) {		
} 
},

error: function(){						
    alert('Error while request..');
} 
});                

}


function edit_record(id,name,desc,video,duration,of_link)
{
    document.getElementById('pop_id').value=id;
    document.getElementById('name').value=name;
    document.getElementById('description').value=desc;
    document.getElementById('v_link').value=video;
    document.getElementById('duration').value=duration;
    document.getElementById('o_link').value=of_link;
//        alert(name);alert(desc);alert(video);alert(duration);
document.getElementById('pop').click();
}
function edit_video(){
    document.getElementById('exam_full').style.display="none";
    document.getElementById('subject_full').style.display="none";
    document.getElementById('chapter_full').style.display="none";
    document.getElementById('topic_full').style.display="none";
    document.getElementById('add_full').style.display="none";
    document.getElementById('submit_full').style.display="";
    
}
function submit_edited(){
    if ($('#name').val() == '')
    {
        $("#popup_button2").click();
        $("#error_message").append("Please Fill Name Field ");
        return;
    }
    else if ($('#description').val() == '')
    {
        $("#popup_button2").click();
        $("#error_message").append("Please Fill Description Field ");
        return;
    }
    else if ($('#v_link').val() == '')
    {
        $("#popup_button2").click();
        $("#error_message").append("Please Fill Video Field ");
        return;
    }
    else if ($('#duration').val() == '')
    {
        $("#popup_button2").click();
        $("#error_message").append("Please Fill This Field ");
        return;
    }
    else
        var id = document.getElementById('pop_id').value;
    var editname = document.getElementById('name').value;
    var editdesc = document.getElementById('description').value;
    var editvideo = document.getElementById('v_link').value;
    var editsource = document.getElementById('o_link').value;
    var editduration = document.getElementById('duration').value; 
//        alert(editname);alert(editdesc);alert(editvideo);alert(editduration);alert(id);
$.ajax({
    type: "POST",
    url: "<?php echo base_url(); ?>admin/editVideoFile",
    data: {id:id,editname:editname,editdesc:editdesc,editvideo:editvideo,editsource:editsource,editduration:editduration},
    cache: false,
    success: function (data)
    
    {
//                    alert(data);
$("#terror1").hide();
$("#message").empty();
if (data != 0)
{
    $("#popup_button").click();
    $("#message").append("Video File Edited Succesfully");
}
else
{
    $("#popup_button").click();
    $("#message").append("Sorry, Something went wrong");
}
},
error: function (err)
{
    alert("Error while request");
    alert(JSON.stringify(err));
}
});
}
</script>
</html>


