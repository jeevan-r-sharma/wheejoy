<!DOCTYPE html>
<html>

<?php include('common.php'); ?>    

<body> 
    <!-- Right side column. Contains the navbar and content of the page -->
    <aside class="right-side">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                User Details
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo base_url(); ?>dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
                <!--                        <li>Refer A Friend</li>-->
                <li class="active">User Details</li>
            </ol>
        </section>
        <aside>
            <section class="content-header">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="row form-3">
                         <form class="form-horizontal form-shade" name="myInfo" id="myInfo" >
                            <div class="form-group"></div>
                            <div class="form-group">
                            <label for="text1" class="control-label col-lg-4">Select Exam</label>
                            <span style="color:red" id="error_exam"></span>
                            <div class="col-lg-5">
                                <select class="form-control" id="exam" name="exam" onblur="validateExam()" onchange="javascript:get_exam(),validateExam()">
                                    <option value="0">Select Exam</option>
                                    <?php
                                    $co = count($g[0]);
                                    $i = 0;
                                    while ($i < $co) {
                                        echo('<option value="' . $g[0][$i]->id . '">' . $g[0][$i]->name . '</option>');
                                        $i++;
                                    }
                                    ?>
                                </select>                       
                            </div>
                        </div> 
                            <div class="form-group">
                                <label for="text1" class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12">First Name</label>
                                <span style="color:red" id="errorfn"></span>
                                <div class="col-lg-5 col-md-8 col-sm-8 col-xs-12">
                                    <input type="text" placeholder="First Name" class="form-control1" id="first_name" name="first_name" value="" onblur="validate_fname();"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="text1" class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12">Last Name</label>
                                <span style="color:red" id="errorln"></span>
                                <div class="col-lg-5 col-md-8 col-sm-8 col-xs-12">
                                    <input type="text" placeholder="Last Name" class="form-control1" id="last_name" name="last_name" value="" onblur="validate_lname();"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="text1" class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12" >Gender</label>
                                <span style="color:red" id="error-gender"></span>
                                <div class="col-lg-5 col-md-8 col-sm-8 col-xs-12">
                                    <div class="custom-radio">
                                        <label class="ext-size"><input class="uniform-radiobox" type="radio" value="male" name="gender" id="gender1" />&nbsp; Male</label>
                                        <label class="ext-size"><input class="uniform-radiobox" type="radio" value="female" name="gender" id="gender2"/>&nbsp;Female</label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="text1" class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12">Contact Number</label>
                                <span style="color:red" id="errorphone"></span>
                                <div class="col-lg-5 col-md-8 col-sm-8 col-xs-12">
                                    <input placeholder="Your Phone" type="text" class="form-control1" pattern="\d{3}[\-]\d{3}[\-]\d{4}" maxlength="10"  name="contact" id="contact" data-mask="999-999-9999" onfocusout="validate_phone(document.myInfo.contact.value);"  onchange="javascript:ajxContact();"/>
                                    <!--                                            <span style="color:red" id="error1"></span>-->
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="text1"
                                class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12">Email-id/User Name</label>
                                <span style="color:red" id="error-email"></span>
                                <div class="col-lg-5 col-md-8
                                col-sm-8 col-xs-12">
                                <input type="text" placeholder="Email" class="form-control1" id="emailid" name="emailid" onfocusout="validateEmail(document.myInfo.emailid.value);" onchange="ajxEmailId()" />
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="text1" class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12" id="error_password">Password</label>
                            <span style="color:red" id="errorpass"></span>
                            <div class="col-lg-5 col-md-8 col-sm-8 col-xs-12">
                                <input placeholder="Your Password" type="password" class="form-control1" pattern="\d{3}[\-]\d{3}[\-]\d{4}"   name="password" id="password" data-mask="999-999-9999"  onchange="javascript:validatePassword();"/>
                                <!--                                            <span style="color:red" id="error1"></span>-->
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="text1" class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12" id="error_password">Re-enter Password</label>
                            <span style="color:red" id="errorRpass"></span>
                            <div class="col-lg-5 col-md-8 col-sm-8 col-xs-12">
                                <input placeholder="Your Password" type="password" class="form-control1" pattern="\d{3}[\-]\d{3}[\-]\d{4}"   name="rpassword" id="rpassword" data-mask="999-999-9999" onblur="validate_rpassword()" onchange="javascript:validate_rpassword();"/>
                                <!--                                            <span style="color:red" id="error1"></span>-->
                            </div>
                        </div> 

                        <div class="form-group">
                            <label class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12">City</label>
                            <span style="color:red" id="error_city"></span>
                            <div class="col-lg-5 col-md-8 col-sm-8 col-xs-12">

                                <input type="text" placeholder="Enter City" class="form-control1" id="c_cities" name="c_cities" value="" onblur="validateCity();"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12">College Name</label>
                            <span style="color:red" id="error_college"></span>
                            <div class="col-lg-5 col-md-8 col-sm-8 col-xs-12">

                                <input type="text" placeholder="Enter College" class="form-control1" id="college" name="colleges" value="" onblur="validateCollege();"/>
                                <span style="color:red" id="err"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-lg-9">
                                <a href="#" class="btn btn-primary pull-right" id="save" name="bttn" onclick="insert_user();">Save</a>

                            </div>	
                        </div>
                    </form>
                    <div class="clearfix">&nbsp;</div>
                    <div id="tab" name="tab" style="display:none;" class="box-body table-responsive">
                        <div id="example2_wrapper" class="dataTables_wrapper form-inline" role="grid">
                            <div class="row"><div class="col-xs-6"></div><div class="col-xs-6"></div></div>
                            <table aria-describedby="example2_info" id="example3" class="table table-bordered table-hover dataTable">
                                <!--<tbody aria-relevant="all" aria-live="polite" role="alert"><tr class="odd black">-->
                                <tr class="odd black">
                                    <td class="text-center">SR NO</td>
                                    <td class="text-center">User ID</td>
                                    <td class="text-center">First Name</td>
                                    <td class="text-center">Last Name</td>
                                    <td class="text-center">Password</td>
                                    <td class="text-center">Date Of Birth</td>
                                    <td class="text-center">Gender</td>
                                    <td class="text-center">College Name</td>
                                    <td class="text-center">Email ID</td>
                                    <td class="text-center">Subscription</td>
                                    <td class="text-center">Status</td>
                                </tr>
                                <!--</tbody>-->
                            </table>
                        </div>
                    </div><!-- /.box-body -->

                </div>
            </div>
        </div> 

        <!-- Update Pop up -->
        <div id= "GSCCquerydetails" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">

            </div> 
        </section><!-- /.content -->  

        <div class="clearfix"></div>

        <!--                    </form>-->
    </section><!-- /.content -->
    <div id="popup_message" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog custom-alert">
            <div class="modal-content" style="margin-top:20%;">
                <div class="modal-header alert-success">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="javascript:location.href = ''">&times; </button>
                    <h4 class="modal-title" id="myModalLabel">Message</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12" id="message">
                        </div>
                    </div>
                </div>
                <div class="modal-footer alert-footer">
                    <a href="javascript:location.href=''" class="btn btn-success">ok</a>
                </div>
            </div>
        </div>
    </div>
    <div id="popup_error" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog custom-alert">
            <div class="modal-content" style="margin-top:20%;">
                <div class="modal-header alert-success">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="">&times; </button>
                    <h4 class="modal-title" id="myModalLabel">Message</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12" id="error_message">
                        </div>
                    </div>
                </div>  
                <div class="modal-footer alert-footer">
                    <a href="#" class="btn btn-success" data-dismiss="modal">ok</a>
                </div>
            </div>
        </div>
    </div>  
    <button class="hide" id="popup_button" data-toggle="modal" data-target="#popup_message"></button>
    <button class="hide" id="popup_button2" data-toggle="modal" data-target="#popup_error"></button>
</aside><!-- /.right-side -->
</div><!-- ./wrapper -->

</body>
<script type="text/javascript">
 function validate_fname()
 {
    var fn=document.getElementById("first_name").value;
    var name=(/^([a-z ,A-Z])+$/);
    if(!fn.match(name))
    {
       document.getElementById("errorfn").innerHTML="Please enter a valid first name";
       document.getElementById("first_name").value="";
       document.getElementById("first_name").focus();
   }
   else
   {
      document.getElementById("last_name").focus();
      document.getElementById("errorfn").innerHTML="";
  }


}
function validate_lname()
{
    var fn=document.getElementById("last_name").value;
    var name=(/^([a-z ,A-Z])+$/);
    if(!fn.match(name))
    {
       document.getElementById("errorln").innerHTML="Please enter a valid Last name";
       document.getElementById("last_name").value="";
       document.getElementById("last_name").focus();
   }
   else
   {
    document.getElementById("gender").focus();
    document.getElementById("errorln").innerHTML="";
}


}
function validate_phone()
{

   var ph=document.getElementById("contact").value;

   if(ph.length<10)
   {
       document.getElementById("errorphone").innerHTML="Please enter a valid phone number";
       document.getElementById("contact").value="";
       document.getElementById("contact").focus();
   }
   else
   {
    document.getElementById("errorphone").innerHTML="";
}
}
function ajxContact() {
//            alert("hi");
var contact = document.getElementById('contact').value;
contact.innerHTML = "";
$.ajax({
    type: "POST",
    url: "<?php echo base_url();?>dashboard/checkPhoneNumber",
    cache: false,
//                    data: $('#myInfo').serialize(),
data:{contact:contact},
success: function (data) {
    try {
        if (data == 1) {
            document.getElementById("errorphone").innerHTML = "Phone Number Exists! Try different";
            document.getElementById('contact').innerhtml = "";
            document.getElementById('contact').value = "";
            document.getElementById('contact').focus();
        }
    } catch (e) {
        alert('Exception while request..!!!...');
    }
},
error: function () {
    alert('Error while request....');
}
});
}
function validateEmail(inputvalue)
{
    var pattern = /^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_.-])+\.([a-zA-Z])+([a-zA-Z])+/;
    if (pattern.test(inputvalue)) {
        document.getElementById("error-email").innerHTML = "";
    }
    else
    {
        document.getElementById("error-email").innerHTML = "Pls enter valid Email Address";
    }
}
function ajxEmailId() {
//            alert("hi");
var emailid = document.getElementById('emailid').value;
emailid.innerHTML = "";
$.ajax({
    type: "POST",
    url: "<?php echo base_url();?>dashboard/checkEmailId",
    cache: false,
//                    data: $('#myInfo').serialize(),
data:{emailid:emailid},
success: function (data) {
    try {
        if (data == 1) {
            document.getElementById("error-email").innerHTML = "Email Exists! Enter different email";
            document.getElementById('emailid').innerhtml = "";
            document.getElementById('emailid').value = "";
            document.getElementById('emailid').focus();
        }
    } catch (e) {
        alert('Exception while request..!!!...');
    }
},
error: function () {
    alert('Error while request....');
}
});
}

function validatePassword()
{
    $("#errorpass").empty();
    var Regex = /(?=.*\d)(?=.*[a-z]).{6,}/;
    var userName = $("#password").val();
    var res = userName.match(Regex);
    if (res == null)
    {
        $("#errorpass").append("Must containes 6 char,lowercase,number");
        $("#password").empty();
    }
}
function validate_rpassword()
{
    var pass = document.getElementById('password').value;
    var rpass = document.getElementById('rpassword').value;
    
    if (rpass==pass) {
        document.getElementById("errorRpass").innerHTML ="";
        return true;
    }
    else
    {
    //                alert("Invalid email ID");
    document.getElementById('rpassword').value = "";
    document.getElementById("errorRpass").innerHTML = "Re-entered password does not match";
    document.getElementById('rpassword').focus();
    return false;
}
}
function validateExam()
{
//                alert("hi");

var batch = document.getElementById('exam').value;
if(batch == 0){
   document.getElementById("error_exam").innerHTML="Please select a Exam";
}else{
   document.getElementById("error_exam").innerHTML="";
}
}
function validateCity()
{
//                alert("hi");

var batch = document.getElementById('c_cities').value;
if(batch == ''){
   document.getElementById("error_city").innerHTML="Please select a city";
}else{
   document.getElementById("error_city").innerHTML="";
}
}
function validateCollege()
{
    var batch = document.getElementById('college').value;
    if(batch == ''){
       document.getElementById("error_college").innerHTML="Please select a college";
   }else{
       document.getElementById("error_college").innerHTML="";
   } 
}

$('#save').click(function (e)
{
    var cstates = $("#c_states").val();
    var exam = $("#exam").val();
//            var cdistricts = $("#c_districts").val();
var ccities = $("#c_cities").val();
var colleges = $("#college").val();
//            var addcoll = $("#addcol").val();
document.getElementById("save").disabled = true;

if ($("#first_name").val() == "")
{
//                alert("hi");
document.getElementById("errorfn").innerHTML="Please enter a valid first name";
}
else
{
    document.getElementById("errorfn").innerHTML="";
}
if ($("#last_name").val() == "")
{
   document.getElementById("errorln").innerHTML="Please enter a valid last name";
}
else
{
    document.getElementById("errorln").innerHTML="";
}

if ($("input[name=gender]").is(":checked"))
{
   document.getElementById("error-gender").innerHTML="";
//        return false;
}
else
{
    document.getElementById("error-gender").innerHTML="Please select a gender";
}

if ($("#password").val() == "")
{
   document.getElementById("errorpass").innerHTML="Please enter password";
}
else
{
    document.getElementById("errorpass").innerHTML="";
}
if ($("#rpassword").val() == "")
{
   document.getElementById("errorRpass").innerHTML="Please enter password";
}
else
{
    document.getElementById("errorRpass").innerHTML="";
}

if ($("#contact").val() == "")
{
    document.getElementById("errorphone").innerHTML="Please enter your phone number";
}
else
{
    document.getElementById("errorphone").innerHTML="";
}
if ($("#emailid").val() == "")
{
    document.getElementById("error-email").innerHTML="Please enter your email";
}
else
{
    document.getElementById("error-email").innerHTML="";
}

if ($("#exam").val() == "0")
{
    document.getElementById("error_exam").innerHTML="Please select state";
}
else
{
    document.getElementById("error_exam").innerHTML="";
}
if ($("#c_cities").val() == "")
{
    document.getElementById("error_city").innerHTML="Please select city";
}
else
{
    document.getElementById("error_city").innerHTML="";
}
if ($("#college").val() == "")
{
    document.getElementById("error_college").innerHTML="Please select college";
}
else
{
    document.getElementById("error_college").innerHTML="";
}
});
</script>
<script type="text/javascript">
    var g_value= 0;
    function pagination()
    {
       var cnt = document.getElementById('cnt').value;
       alert(cnt);
   }
   function insert_user()
   {
     if (document.getElementById('gender1').checked) {
        g_value = document.getElementById('gender1').value;
//                alert(g_value);
}
if (document.getElementById('gender2').checked) {
    g_value = document.getElementById('gender2').value;
//                alert(g_value);
} 
$("#error_message").empty();
if ($("#first_name").val() == '')
{
    $("#popup_button2").click();
    $("#error_message").append("Please Fill First Name Field");
    return;
}
else if ($('#last_name').val() == '')
{
    $("#popup_button2").click();
    $("#error_message").append("Please Fill Last Name Field");
    return;
}
else if (g_value == 0)
{
    $("#popup_button2").click();
    $("#error_message").append("Please Select Gender");
    return;
}
else if ($('#contact').val() == '')
{
    $("#popup_button2").click();
    $("#error_message").append("Please Fill Contact Field");
    return;
}
else if ($('#emailid').val() == '')
{
    $("#popup_button2").click();
    $("#error_message").append("Please Fill Email-id Field");
    return;
}
else if ($('#password').val() == '')
{
    $("#popup_button2").click();
    $("#error_message").append("Please Fill Password Field");
    return;
}
else if ($('#rpassword').val() == '')
{
    $("#popup_button2").click();
    $("#error_message").append("Please Fill Re-password Field");
    return;
}
else if ($("#exam").val() == 0)
{
    $("#popup_button2").click();
    $("#error_message").append("Please select Exam");
    return;
}
else if ($('#c_cities').val() == '')
{
    $("#popup_button2").click();
    $("#error_message").append("Please select City");
    return;
}
else if ($('#college').val() == '')
{
    $("#popup_button2").click();
    $("#error_message").append("Please select College");
    return;
}
else 
    var f_name = document.getElementById('first_name').value;
var l_name = document.getElementById('last_name').value;
var gender = g_value;
var contact = document.getElementById('contact').value;
var email = document.getElementById('emailid').value;
var pass = document.getElementById('password').value;
var repass = document.getElementById('rpassword').value;
var exam  = document.getElementById('exam').value;
//                    var state  = document.getElementById('c_states').value;
var city = document.getElementById('c_cities').value;
var college = document.getElementById('college').value;

$.ajax({
   type: "POST",
   url: "<?php echo base_url(); ?>dashboard/insert_user_by_admin",
   cache: false,				
   data: {f_name:f_name,l_name:l_name,gender:gender,contact:contact,email:email,pass:pass,exam:exam,city:city,college:college},
   success: function(data){
    alert(data);
    $("#terror1").hide();
    $("#message").empty();
    if (data != 0)
    {
        $("#popup_button").click();
        $("#message").append("User Added Succesfully");
    }
    else
    {
        $("#popup_button").click();
        $("#message").append("Sorry, Something went wrong");
    }
},
error: function (err)
{
    alert("Error while request");
    alert(JSON.stringify(err));
}
});
} 

function getCities() {
  var state_id = $('#c_states').val();
//          alert(state_id);
var drpDown = document.getElementById('c_cities');
drpDown.innerHTML = "";
//            $("#c_districts").css({
//            "border": "",
//            "background": ""
//            });
$.ajax({
   type: "POST",
   url: "<?php echo base_url();?>dashboard/getcities",
   cache: false,				
   data:{state_id:state_id}, 
   success: function(data){						
//                        alert(data);
try{
   if(data.length>0)
   {
    obj = jQuery.parseJSON(data);
    var el = document.createElement("option");
    el.textContent = "Select city";
    el.value = "0";
    drpDown.appendChild(el);
    for (i = 0; i < obj.length; i++)
    {
        var opt = obj[i]['id'];
        var desc = obj[i]['name'];
        var el = document.createElement("option");
        el.textContent = desc;
        el.value = opt;
        drpDown.appendChild(el);
    }
}
} 
catch (e) {
    alert('Exception while request..');
}
},
error: function () {
    alert('Error while request..');
}
});
}
function getCollege() {
  var city_id = $('#c_cities').val();
//          alert(city_id);
var drpDown = document.getElementById('college');
drpDown.innerHTML = "";
$.ajax({
   type: "POST",
   url: "<?php echo base_url();?>dashboard/getcollege",
   cache: false,				
   data:{city_id:city_id}, 
   success: function(data){						
//                        alert(data);
try{
    if(data.length>0)
    {
        obj = jQuery.parseJSON(data);
        var el = document.createElement("option");
        el.textContent = "Select College";
        el.value = "0";
        drpDown.appendChild(el);
        for (i = 0; i < obj.length; i++)
        {
            var opt = obj[i]['id'];
            var desc = obj[i]['name'];
            var el = document.createElement("option");
            el.textContent = desc;
            el.value = opt;
            drpDown.appendChild(el);
        }
    }
} catch (e) {
    alert('Exception while request..');
}
},
error: function () {
    alert('Error while request..');
}
});
}

</script>
</html>
