<!DOCTYPE html>
<html>
    <?php include('common.php'); ?>
     <body class="skin-blue">
      <form name="myform" id="myform">
       <aside class="right-side">
       <section class="content-header">
        <h1>
            Sorry, No Questions Available on this Topic.
            Please Try Other topics.
        </h1>
           <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
        </ol>
        </section>
       </aside>
      </form>
    </body>
</html>
