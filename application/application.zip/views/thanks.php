
<!DOCTYPE html>
<html>
    <?php include('common.php'); ?>
   
       <body class="skin-blue">
      <form name="myform" id="myform">
       <aside class="right-side">
       <section class="content-header">
        <h1><i>
          Result:
            </i> </h1>
           <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
            
        </ol>
        </section>
           <table aria-describedby="example2_info" id="example2" class="table table-bordered table-hover dataTable">
               <tbody aria-relevant="all" aria-live="polite" role="alert">
               <tr  class="odd black">
                   <td class="  sorting_1">Que</td>
                   <td class="text-center">C.Ans</td>
                   <td class="text-center">U.Ans</td>
                   <td class="  sorting_1">Que</td>
                   <td class="text-center">C.Ans</td>
                   <td class="text-center">U.Ans</td>
                   <td class="  sorting_1">Que</td>
                   <td class="text-center">C.Ans</td>
                   <td class="text-center">U.Ans</td>
                   <td class="  sorting_1">Que</td>
                   <td class="text-center">C.Ans</td>
                   <td class="text-center">U.Ans</td>
               </tr>
               <?php 
                $j=0;
                       $k=0;
                       $l=0;
               for($i=0;$i<15;$i++)
               {
                   $j=$i+16;
                   $k=$i+30;
                   $l=$i+45;
                   $m=$i+1;
                   $n=$k+1;
                   $o= $l+1;
                  
                   echo '<tr>
                       
                              <td>'.$m.'</td>
                              <td>'.$r[$i]->corr_ans.'</td>
                              <td>'.$r[$i]->user_ans.'</td>
                              <td>'.$j.'</td>
                              <td>'.$r[$j]->corr_ans.'</td>
                              <td>'.$r[$j]->user_ans.'</td>
                              <td>'.$n.'</td>
                              <td>'.$r[$k]->corr_ans.'</td>
                              <td>'.$r[$k]->user_ans.'</td>
                              <td>'.$o.'</td>
                              <td>'.$r[$l]->corr_ans.'</td>
                              <td>'.$r[$l]->user_ans.'</td>
                        </tr>';
               }
               ?>
               </tbody>
           </table>
       </aside>
      </form>
    </body>
   
    
</html>
