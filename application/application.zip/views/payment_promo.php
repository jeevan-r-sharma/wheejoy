
<!doctype html>
<html>
    <?php include('common.php'); ?>
    <head>

    </head>
    <body>
        <aside class="right-side">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>
                    Promo Code</h1>
                <ol class="breadcrumb">
                    <li><a href="<?php echo base_url(); ?>dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li class="active">User Details</li>
                </ol>
            </section>
            <section class="content">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="row form-3">
                            <h5 class="form-title">User Details</h5>
                            <!--------------------------------------form-3-start------------------------------------->
                            <form class="form-horizontal form-shade" id="myInfo" name="myInfo">
                                <input type="hidden" name="uid" id="uid" value="<?php echo $u[0]->userid; ?>">
                                <div class="form-group">
                                    <label for="text1" class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12">User Name</label>
                                    <div class="col-lg-5 col-md-8 col-sm-8 col-xs-12">
                                        <input type="text" name="name" id="name" value ="<?php echo $u[0]->first_name; ?> <?php echo $u[0]->last_name; ?>" autocomplete="off" class="form-control"  readonly/>
                                    </div>
                                </div>
                                <div class="form-group" id="div1" name="div1" >
                                    <label for="text1" class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12">Subscription</label>
                                    <div class="col-lg-5 col-md-9 col-sm-9 col-xs-12">
                                        <select class="form-control" id="subscription" name="exm1">
                                            <option value=0>select Subscription</option>
                                            <?php
                                            echo $c = count($subscriptions);
                                            $i = 0;
                                            while ($i < $c):
                                                ?>
                                                <option value="<?php echo $subscriptions[$i]['id']; ?>"><?php echo $subscriptions[$i]['name']; ?></option>
                                                <?php
                                                $i++;
                                            endwhile;
                                            ?>

                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="text1" class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12">Valid For (No. Of Day's)</label>
                                    <div class="col-lg-5 col-md-8 col-sm-8 col-xs-12">
                                        <input type="text" class="form-control" id="days" name="days"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="text1" class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12">Promo Code</label>
                                    <div class="col-lg-5 col-md-8 col-sm-8 col-xs-12">
                                        <div class="input-group">
                                            <input type="text" class="form-control" id="promo" name="promo" readonly/>                                    
                                            <div class="input-group-btn">
                                                <button type="button" class="btn btn-primary" onclick="javascript:randomString();">Generate</button>
                                            </div><!-- /btn-group -->
                                        </div><!-- /input-group -->	
                                    </div>
                                    <!--a href="javascript:generate()"  class="btn btn-primary pull-right" style="display:block;margin:0 3px;">Generate</a-->
                                </div>
                                <div class="form-group">
                                    <label for="text1" class="control-label col-lg-4 col-md-3 col-sm-3 col-xs-12">Amount</label>
                                    <div class="col-lg-5 col-md-8 col-sm-8 col-xs-12">
                                        <input type="text" class="form-control" id="amount" name="days"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-9 col-sm-11 col-md-11 col-xs-12">
                                        <a href="javascript:savePromo()"  class="btn btn-primary pull-right" style="display:block;margin:0 3px;">Save</a>
                                    </div>	
                                </div> 
                            </form>
                        </div>
                    </div>
                </div>                  
            </section><!-- /.content -->
        </aside><!-- /.right-side -->
    </div><!-- ./wrapper -->        
</body>
<script type="text/javascript">
    function randomString() {
        var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZ";
        var string_length = 6;
        var randomstring = '';
        for (var i = 0; i < string_length; i++) {
            var rnum = Math.floor(Math.random() * chars.length);
            randomstring += chars.substring(rnum, rnum + 1);
        }
        document.getElementById('promo').value = randomstring;
    }

    function savePromo()
    {
        var userid = document.getElementById('uid').value;
        var code = document.getElementById('promo').value;
        var days = document.getElementById('days').value;
        var subscription = $("#subscription").val();
        var amount = $("#amount").val();
        if (days == "")
        {
            alert("Please Enter No Of Days");
            return false;
        }
        if (amount == "")
        {
            alert("Please Enter Amount");
            return false;
        }
        if (subscription == 0)
        {
            alert("Please Select subscription");
            return false;
        }
        if (code == "")
        {
            alert("Click on Generate for Random promocode");
        }
        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>admin/savePromo",
            data: {userid: userid, code: code, days: days,subscription:subscription,amount:amount},
            success: function (data)
            {
//                alert(data);
                if (data)
                {
                    alert("Promocode Generated");

                }
                else
                {
                    alert("failed to generate promo Code. Try Again!!!")
                }
            },
            error: function ()
            {
                alert("error while request");
            }
        });

    }
</script>
</html>    