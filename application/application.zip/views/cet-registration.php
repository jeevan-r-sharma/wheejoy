<!DOCTYPE html>
<html>
    
 <?php include('common.php'); ?>    

 <body> 
    
  
    <!-- Right side column. Contains the navbar and content of the page -->
    <aside class="right-side">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                User Lists
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo base_url(); ?>dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
                <!--                        <li>Refer A Friend</li>-->

                <li class="active">User Lists</li>
            </ol>
        </section>
        <aside>
            <section class="content">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="row form-3">
                            <!--<h5 class="form-title">User Lists</h5>-->
                            <!--form-3-start-->
                            <form class="form-horizontal form-shade" id="myInfo" name="myInfo">
                                <div class="form-group">
                                    <label for="text1" class="control-label col-lg-4">First Name</label>
                                    <div class="col-lg-5">
                                        <input type="text" placeholder="First Name" class="form-control" value="" id="f_name" name="fname" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="text1" class="control-label col-lg-4">Last Name</label>
                                    <div class="col-lg-5">
                                        <input type="text" placeholder="Last Name" class="form-control" value="" id="l_name" name="lname" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="text1" class="control-label col-lg-4">Email Id</label>
                                    <div class="col-lg-5">
                                        <input type="text" name="name" id="email_id" value ="" autocomplete="off" class="form-control" placeholder="Enter Emailid" required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="text1" class="control-label col-lg-4">Phone</label>
                                    <div class="col-lg-5">
                                        <input type="text" placeholder="Phone Number" class="form-control" value="" id="phone_no" name="lname" maxlength="10"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-9">
                                        <a href="#"  class="btn btn-primary pull-right" onclick="searchStudent()" style="display:block;margin:0 3px;">Search User</a>
                                        <button class="hide" id="popupbutton" data-toggle='modal' data-target='#GSCCquerydetails'>Edit</button>
                                    </div>	
                                </div>    
                                <span style="color:red" id="error"></span>
                            </form>
                            <!-- First-table-->
                            <div class="row" style=" margin-top: -21px;">
                                <section class="col-lg-12 connectedSortable">					
                                    <div class="box-body table-responsive">
                                        <span id="terror2" name="terror2" style="color:red;"></span><br>
                                        <div id="example2_wrapper" class="dataTables_wrapper form-inline" role="grid">
                                            <div class="col-md-12 text-center"></div> 
                                            <div class="row">
                                                <div class="col-xs-6"></div>
                                                <div class="col-xs-6"></div>
                                            </div>
                                            <div id="pagelink" class="pagination pull-right"><?php
                                                if (isset($result_per_page)) {
                                                    echo $this->pagination->create_links();
                                                }
                                                ?>
                                            </div>
                                            <!-- <div style="float: right;">
                                                <?php //echo $this->pagination->create_links(); ?>
                                            </div> -->
                                            <div class="row">
                                                <div class="col-xs-6"></div>
                                                <div class="col-xs-6"></div></div>
                                                <table aria-describedby="example2_info" id="table2" class="table table-bordered table-hover dataTable">       
                                                    <tbody aria-relevant="all" aria-live="polite" role="alert">
                                                        <tr class="odd black">
                                                            <td class="hide"></td>
                                                            <td class="text-center">Sl No.</td>
                                                            <td class="text-center">Name</td>
                                                            <td class="text-center">Email-ID</td>
                                                            <td class="text-center">Phone no</td>
                                                            <td class="text-center">College Name</td>
                                                            <td class="text-center">Exam Plan</td>
                                                            <td class="text-center">City</td> 
                                                            <td class="text-center">Created On</td> 
                                                            <td class="text-center">Status</td> 
                                                            <td class="text-center">Plan</td>
                                                <!--<td class="text-center">District</td>                                               
                                               	<td class="text-center">Plan</td>
                                                <td class="text-center">Date</td>-->
                                                
                                            </tr>
                                            <tr class="even">
                                                
                                                <?php $i=1;
                                                $j=$this->session->userdata('count')+1;
//                                                        while($i<$count)
                                                if($j>0){
                                                    foreach($result_per_page[0] as $row){?>
                                                    <tr class="even">
                                                        
                                                        <td class="text-center"><?php echo $j; ?></td>
                                                        <td class="text-center"><?php echo $row->F_name; ?></td> 
                                                        <td class="text-center"><?php echo $row->email; ?></td> 	
                                                        <td class="text-center"><?php echo $row->phonenumber; ?></td>
                                                        <td class="text-center"><?php echo $row->College; ?></td> 
                                                        <td class="text-center"><?php echo $row->exam; ?></td>
                                                        <td class="text-center"><?php echo $row->City; ?></td>
                                                        <td class="text-center"><?php echo $row->Date; ?></td>
                                                        <td class="text-center"><?php echo $row->status; ?></td>
                                                        <td class="text-center">
                                                            <a href="javascript:popUpCall(<?php echo $row->userid;?>);" class="btn btn-primary">
                                                                Change Plan</a>
                                                            </td>
                                                            
<!--                                                <td class="text-center"><?php //echo $row->District; ?></td>
                                                <td class="text-center"><?php //echo $row->Plan; ?></td>
                                                <td class="text-center"><?php //echo $row->Date; ?></td>-->
                                                
                                                
                                            </tr>
                                            <?php  $i = $i+1; $j++;
                                        }
                                    } else {
                                        echo '<tr><td colspan="9" style="color: red;">No Records Found</td></tr>';
                                    }
//                                            ?>   
</tbody>
</table>
</div>
</div>
</section>
<div class="box-body table-responsive">
    <span id="terror1" name="terror1" style="color:red;"></span><br>
    <div id="example1_wrapper" class="dataTables_wrapper form-inline" role="grid">
        <div class="col-md-12 text-center"><h3></h3></div> 
        <div class="row">
            <div class="col-xs-6"></div>
            <div class="col-xs-6"></div>
            <div class="row">
                <div class="col-xs-6"></div>
                <div class="col-xs-6"></div></div>
                <table aria-describedby="example2_info" id="table1" class="table table-bordered table-hover dataTable" style="display: none;">       
                    <tbody aria-relevant="all" aria-live="polite" role="alert">
                        <tr class="odd black">
                            <td class="hide"></td>
                            <td class="text-center">Sl No.</td>
                            <td class="text-center">Name</td>
                            <td class="text-center">Email-ID</td>
                            <td class="text-center">Phone no</td>
                            <td class="text-center">College Name</td>
                            <td class="text-center">Exam Plan</td>
                            <td class="text-center">City</td> 
                            <td class="text-center">Created On</td> 
                            <!--<td class="text-center">Status</td>-->
                            <td class="text-center">Plan</td>
                                                <!--<td class="text-center">District</td>                                               
                                               	<td class="text-center">Plan</td>
                                                <td class="text-center">Date</td>-->
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div><!-- /.box-body -->
                    
                </div>
            </div>
        </div> 

        <!-- Update Pop up -->
        <div id= "GSCCquerydetails" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content" >
                    <div class="modal-header">
                        <button type="button" class="close" id="popupclose" data-dismiss="modal" aria-hidden="true">&times;  </button>
                        <h4 class="modal-title" id="myModalLabel">Update Plan</h4>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-lg-12 col-md-12">

                                <div class="form-group" id="ques" name="ques">
                                    <label class="ext-size text-center col-lg-3 col-md-3 col-sm-3 col-xs-12" for="text1">Plan</label>
                                    <div class="col-lg-9 col-sm-9 col-md-9 col-xs-12">
                                        <div class="col-lg-5 form-control1">
                                            <select class="form-control1" id="uexam" name="uexam" onblur="validateExam()" onchange="javascript:get_exam(),validateExam()">
                                                <option value="0">Select Exam</option>
                                                <?php
                                                $co = count($result_per_page[1]);
                                                $i = 0;
                                                while ($i < $co) {
                                                    echo('<option value="' . $result_per_page[1][$i]->id . '">' . $result_per_page[1][$i]->name . '</option>');
                                                    $i++;
                                                }
                                                ?>
                                            </select>						
                                        </div>
                                        <span id="error101" style="color:red" style="display:none;"></span>
                                        <input class="hide" type="text" class="form-control1" name="userid" id="userid" readonly="">
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                        <div class="modal-footer">
                            <input type="text" class="hide" id="question_id">
                            <div id="question_id" name="ans" class="pull-right">
                                <a href="javascript:updatePlan()" class="btn btn-primary">Change</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        </section><!-- /.content -->  
        
        <aside>
</section><!-- /.content -->
</aside><!-- /.right-side -->
</div><!-- ./wrapper -->

</body>
    <script type="text/javascript">
       
      function searchStudent()
        {
//            alert("hi");
             var fname = document.getElementById('f_name').value;
             var lname = document.getElementById('l_name').value;
             var emailid = document.getElementById('email_id').value;
             var phone = document.getElementById('phone_no').value;
             
             
//            alert(fname);alert(lname);alert(emailid);alert(phone);
        if(fname=="" && lname=="" && emailid=="" && phone=="" )
            {
                alert("fill details atleast one field");
            }else
                $.ajax({
                type: "POST",
                url: "<?php echo base_url(); ?>dashboard/search_student_by_admin",
                data: {fname: fname,lname:lname, emailid: emailid,phone:phone},
                success: function (data)
                {
                 
                    //alert(data);
                    
                    $('#terror2').hide();
                     $("#example2_wrapper").hide();
                     $("#example1_wrapper").show();
                     $('#terror1').show();
                    document.getElementById('table1').style.display = "";
                    var e1 = jQuery.parseJSON(data);
                     if (e1.length > 0) {
                            $("#table1").find("tr:gt(0)").remove();
                            var table = document.getElementById("table1");
//                            table.innerHTML ='';
//a = "<a href='<?php echo base_url(); ?>partner_result_manage/view_student_result/" + obj[i].test_id + "/" + obj[i].test_type + "'>View</a>";

                            for (var i = 0; i < e1.length; i++)
                            {
//                            var prof = "<a href='<?php echo base_url(); ?>dashboard/view_profile/" + e1[i].id+"'>Profile</a>";
//                               var a = "<a href='<?php echo base_url(); ?>dashboard/add_trainer/" + e1[i].id+"'>Add trainer</a>";
//                               if (e1[i]['status'] == 0)
//                               {
//                                   var b = "javascript:edit_notes("+e1[i].id+")>Activate</a>";
////                                   var b = "InActive";
//                               }
//                               else{
//                                   var b = "<a href='<?php echo base_url(); ?>dashboard/add_trainer/" + e1[i].id+"'>Deactivate</a>";
////                                   var b = "Active";
//                               }
                                var tab = table.insertRow(i + 1);
                                var col1 = tab.insertCell(0);
                                $(col1).addClass("text-center");
                                col1.innerHTML = i + 1;
                                var col2 = tab.insertCell(1);
                                $(col2).addClass("text-center");
                                col2.innerHTML = e1[i]['f_name'];
                                var col3 = tab.insertCell(2);
                                $(col3).addClass("text-center");
                                col3.innerHTML = e1[i]['email'];
                                var col4 = tab.insertCell(3);
                                $(col4).addClass("text-center");
                                col4.innerHTML = e1[i]['phone'];
                                var col5 = tab.insertCell(4);
                                $(col5).addClass("text-center");
                                col5.innerHTML = e1[i]['college'];
                                var col6 = tab.insertCell(5);
                                $(col6).addClass("text-center");
                                col6.innerHTML = e1[i]['exam'];
                                var col7 = tab.insertCell(6);
                                $(col7).addClass("text-center");
                                col7.innerHTML = e1[i]['city'];
                                var col8 = tab.insertCell(7);
                                $(col8).addClass("text-center");
                                col8.innerHTML = e1[i]['created_on'];
//                                var col6 = tab.insertCell(5);
//                                $(col6).addClass("text-center");
//                                col6.innerHTML = prof;
//                                if (e1[i]['status'] == 0)
//                               {
//                                var col7 = tab.insertCell(6);
//                                $(col7).addClass("text-center");
//                                col7.innerHTML = "<input type='button' class='btn btn-primary' value='Activate' onclick='new1("+e1[i]['id']+")' />";
////                                   var b = "javascript:edit_notes("+e1[i].id+")>Activate</a>";
////                                   var b = "InActive";
//                               }
//                               else{
//                                var col7 = tab.insertCell(6);
//                                $(col7).addClass("text-center");
//                                col7.innerHTML = "<input type='button' class='btn btn-primary' value='Deactivate' onclick='new1("+e1[i]['id']+")' />";
//                                   var b = "<a href='<?php echo base_url(); ?>sponsors/add_trainer/" + e1[i].id+"'>Deactivate</a>";
//                                   var b = "Active";
//                               }
                                
//                                col9.innerHTML = '<input type="button" class="btn btn-primary" onclick="new1('e1[i]['id']+")" value="Activate">';
                                
//                                col9.innerHTML = e1[i]['status'];                                
//                                var col9 = tab.insertCell(8);
//                                $(col9).addClass("text-center");
//                                col9.innerHTML = '';
                                var col9 = tab.insertCell(8);
                                $(col9).addClass("text-center");
                                col9.innerHTML = "<a href='javascript:popUpCall("+e1[i]['userid']+");' class='btn btn-primary'>Change Plan<a/>";
                                
                            }
                        } else {
                              $("#table1").find("tr:gt(0)").remove();
                             $("#example1_wrapper").show();
                             document.getElementById('terror1').innerHTML = "no records found";
                        }
                },
                error: function (err)
                {
                     alert(JSON.stringify(err));
                    alert("Error while request");
                }
            });
            }

	function popUpCall(userid){
		document.getElementById('error101').style.display = "none";
	    document.getElementById('popupbutton').click();
		document.getElementById('userid').value = userid;
	}
	function updatePlan(){
		var exam_id = document.getElementById('uexam').value;
		var user_id = document.getElementById('userid').value;
		if(exam_id != 0){
			document.getElementById('error101').style.display = "none";
			$.ajax({
                type: "POST",
                url: "<?php echo base_url(); ?>dashboard/updateUserExam",
                catche : false,
                data: {Exam_id:exam_id,User_id:user_id},
                success: function (data)
                {
                    //alert(data);
					obj = jQuery.parseJSON(data);
					if(obj[0].result_status == 1){
						document.getElementById('error101').style.display = "block";
						document.getElementById('error101').innerHTML = "Plan changed";
                                                location.reload();
					}
                },
                error: function (err)
                {
                    //alert("Error while request");
                    //alert(JSON.stringify(err));
                }
            });
		}else{
			document.getElementById('error101').style.display = "block";
			document.getElementById('error101').innerHTML = "Select any plan";
		}
	}
    </script>
</html>
