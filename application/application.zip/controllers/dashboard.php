<?php

class Dashboard extends CI_Controller {

    public $pagination = "";

    function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('subscription_m');
        $this->load->model('dashboard_m');
        $this->load->library('pagination');
    }

    function index() {
        $login_id = $this->session->userdata('usr_session');
        if ($login_id) {
            $limit = 5;
            $offset = ($this->uri->segment(3) != '' ? $this->uri->segment(3) : 0);
            $this->load->model('dashboard_m');
            $config['base_url'] = base_url() . "dashboard/index";
            $total_row = $this->dashboard_m->today_registration_count();
            $config['total_rows'] = $total_row[0]->count; //$this->db->query($qry)->num_rows();
            $config['uri_segment'] = 3;
            $config['per_page'] = $limit;
            $config['num_links'] = 2;
            $config['full_tag_open'] = '<div id="pagination">';
            $config['full_tag_close'] = '</div>';
            $this->session->unset_userdata('count', $offset);
            $this->session->set_userdata('count', $offset);
            $this->pagination->initialize($config);
            $this->load->model('dashboard_m');
            $result['result_per_page'] = $this->dashboard_m->get_daily_subscription_adm($limit, $offset);
            $this->load->view("dashboard",$result);
        } else {
            $this->session->set_userdata("redirect", $_SERVER['REQUEST_URI']);
            redirect('signin', 'refresh');
        }
    }

    function monthlyAdmissionsAdm() {

        $this->load->model('dashboard_m');
        $qarytm = $this->dashboard_m->get_monthly_subscription_adm();
    }

    function free_registration() {
        $this->load->model("dashboard_m");
        $array['a'] = $this->dashboard_m->get_ft_user_details();
//      print_r($array);
        $this->load->view("free-registration", $array);

    }

    function todaySubcriptionCount_adm() {
        $this->load->model("dashboard_m");
        $arr = $this->dashboard_m->today_subscription_details();
        $arr = json_encode($arr);
        echo $arr;
    }

    function getOverallSubscription() {
        $this->load->model("dashboard_m");
        $arr = $this->dashboard_m->get_Overall_Subscription();
        $json = json_encode($arr);
        echo $json;
    }

    function weeklySubscription() {
        $this->load->model('dashboard_m');
        $arr = $this->dashboard_m->get_week_subscription_adm();
        $json = json_encode($arr);
        echo $json;
    }

    function monthlySubscription() {
        $this->load->model('dashboard_m');
        $arr = $this->dashboard_m->get_monthly_subscription_count_adm();
        $json = json_encode($arr);
        echo $json;
    }

    function dashboard_adm() {
        $this->load->model('dashboard_m');
        $arr2 = $this->dashboard_m->get_week_subscription_adm();
        print_r($arr2);
    }

    function User_list() {
        $login_id = $this->session->userdata('usr_session');
      if ($login_id) {
        $limit = 10;
        $offset = ($this->uri->segment(3) != '' ? $this->uri->segment(3):0);
        $this->load->model('dashboard_m');
        $config['base_url'] = base_url() . "dashboard/User_list";
        $total_row = $this->dashboard_m->record_adm_cet_count();
        $config['total_rows'] =$total_row[0]->count;//$this->db->query($qry)->num_rows();
        $config['uri_segment'] = 3;
        $config['per_page'] = $limit;
        $config['num_links'] = 2;
        $config['full_tag_open'] = '<div id="pagination">';
        $config['full_tag_close'] = '</div>';
        $this->session->unset_userdata('count',$offset);
        $this->session->set_userdata('count',$offset);
        $this->pagination->initialize($config);
        // $data['page_link'] = $this->pagination->create_links();
        $data = $this->dashboard_m->get_admin_user_data($limit,$offset);
		$exam = $this->subscription_m->get_view_add_detail();
		$data['result_per_page'] = array($data,$exam);
        $this->load->view("cet-registration", $data);
        } else {
            $this->session->set_userdata("redirect", $_SERVER['REQUEST_URI']);
            redirect('signin', 'Refresh');
        }
    }
    
    function updateUserExam() {
        $exam_id = $_POST["Exam_id"];
		$user_id = $_POST["User_id"];
        $this->load->model('dashboard_m');
        $json = $this->dashboard_m->updateUserExam_m($exam_id,$user_id);
        $data = json_encode($json);
        echo $data;
    }

    function userProfile() {
        $login_id = $this->session->userdata('usr_session');
     if ($login_id) {     
        $this->load->model('dashboard_m');
        $loginid = $this->session->userdata('usr_session');
        $userid = $loginid[0]->registration_no;
        $userdata = $this->dashboard_m->get_admin_user_details($userid);
        $array['g'] = array($userdata);
        $this->load->view("user_profile", $array);
     } else {
            $this->session->set_userdata("redirect", $_SERVER['REQUEST_URI']);
            redirect('signin', 'refresh');
        }
    }

    function add_user() {
        $login_id = $this->session->userdata('usr_session');
        if ($login_id) {
            $this->load->model('subscription_m');
            // $state = $this->subscription_m->states();
            // $exam = $this->subscription_m->get_view_add_detail();
            $exam = $this->subscription_m->getSubscriptionsByInst($login_id[0]->registration_no);
            $array['g'] = array($exam);
            $this->load->view("add_user", $array);
        } else {
            $this->session->set_userdata("redirect", $_SERVER['REQUEST_URI']);
            redirect('signin', 'refresh');
        }
    }
        function add_user_inst() {
        $login_id = $this->session->userdata('usr_session');
        if ($login_id) {
            $this->load->model('subscription_m');
            // $state = $this->subscription_m->states();
            $exam = $this->subscription_m->get_view_add_detail();
            $array['g'] = array($exam);
            $this->load->view("add_user_inst", $array);
        } else {
            $this->session->set_userdata("redirect", $_SERVER['REQUEST_URI']);
            redirect('signin', 'refresh');
        }
    }

    function insert_user_by_admin(){
        $fname=$_POST['f_name'];
        $lname=$_POST['l_name'];
        $gender=$_POST['gender'];
        $contact=$_POST['contact'];
        $email=$_POST['email'];
        $password=$_POST['pass'];
        $exam_id=$_POST['exam'];
        $city_id=$_POST['city'];
        $college_id=$_POST['college'];
        $activation_code = random_string('alnum', 16);
        $this->load->model("dashboard_m");
        $json= $this->dashboard_m->insert_user_by_admin_m($fname,$lname,$gender,$contact,$email,$password,$exam_id,$city_id,$college_id);
//        $json = json_encode($json);
        $result['response']=$json;
        print_r($result);
        // echo $result;
        if ($result['response'][0]->message == "success") {
                   // $this->send_reg_gmail($fname,$email,$password,$activation_code);
                } else {
//                    echo 2;
                }
    }
  function send_reg_gmail($fname,$email,$password,$activation_code){
    $config = Array(
      'protocol' => 'smtp',
      'smtp_host' => 'ssl://smtp.googlemail.com',
      'smtp_port' => 465,
      'smtp_user' => 'contact.sunilsacademy@gmail.com',
      'smtp_pass' => 'sunilacademy123',
      'mailtype'  => 'html', 
      'charset'   => 'iso-8859-1',
      //'smtp_crypto' => 'ssl',
      'SMTPAuth' => 'true'
    );
    $username = $email;
    $pswd = $password;
        $To = $email;
        $Subject = "Sunil Academy Registration Mail";
        $Message = "Dear $fname,\r\n
                              Thank You For Registering with Sunil Academy.\r\n
                              Your account has been created with us, Please find your login credentials.,\n\r
                              User Name : $username
                              Password  : $pswd
          
                \r\n   Happy Practising!
           
                   Thanks & Regards,
                   Sunil Academy";

    $this->load->library('email', $config);
    
    $this->email->from('contact.sunilsacademy@gmail.com', 'Sunil Academy');
    $this->email->to($email); 
    
    $this->email->subject($Subject);
    $this->email->message($Message);  
    
    if ($this->email->send()) {
      //echo 'success';
    } else {
      show_error($this->email->print_debugger());
      return 0;
    } 
  }
    function getState() {
        $this->load->model('subscription_m');
        $array = $this->subscription_m->states();
        $json = json_encode($array);
        echo $json;
    }

    function getcities() {
        $state_id = $_POST['state_id'];
        $this->load->model('subscription_m');
        $json = $this->subscription_m->cities($state_id);
        $json = json_encode($json);
        echo $json;
    }

    function getcollege() {
        $city_id = $_POST['city_id'];
        $this->load->model('subscription_m');
        $json = $this->subscription_m->getCollege($city_id);
        $json = json_encode($json);
        echo $json;
    }

    function checkEmailId() {

        $emailid = $_POST["emailid"];
        $this->load->model('dashboard_m');
        $json = $this->dashboard_m->check_email_exists($emailid);
        $array = json_decode($json);
        $j1 = json_encode($array);
        echo $j1;
    }

    function checkPhoneNumber() {
        $contact = $_POST["contact"];
        $this->load->model('dashboard_m');
        $json = $this->dashboard_m->check_phone_number_exists($contact);
        $array = json_decode($json);
        $j1 = json_encode($array);
        echo $j1;
    }

    function search_student_by_admin() {
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $emailid = $_POST['emailid'];
        $phone = $_POST['phone'];
        $this->load->model('dashboard_m');
        $json = $this->dashboard_m->search_student_by_admin_m($fname, $lname, $emailid, $phone);
        $json = json_encode($json);
        echo $json;
    }

    function Import_user() {
        $login_id = $this->session->userdata('usr_session');
        if ($login_id) {
            $this->load->model('subscription_m');
            // $exam = $this->subscription_m->get_view_add_detail();
            $exam = $this->subscription_m->getSubscriptionsByInst($login_id[0]->registration_no);
            $data['g']= array($exam,"0");
            $this->load->view("import_user",$data);
        } else {
            $this->session->set_userdata("redirect", $_SERVER['REQUEST_URI']);
            redirect('signin', 'refresh');
        }
    }

    function view_questions() {
        $off = $this->uri->slash_segment(3);
        $subject_id = $this->session->userdata('subject_id');
        $chapter_id = $this->session->userdata('chapter_id');
        $topic_id = $this->session->userdata('topic_id');
        $total_row = $this->session->userdata('total_records');
        $level = $this->session->userdata('level');
        if ($off == "/") {
            if (isset($_POST['subject_id']) && isset($_POST['chapter_id']) && isset($_POST['chapter_id']) && isset($_POST['topic_id']) && isset($_POST['level']) && $_POST['subject_id'] != 0 && $_POST['chapter_id'] != 0) {
                $offset = 0;
                $subject_id = $_POST['subject_id'];
                $chapter_id = $_POST['chapter_id'];
                $topic_id = $_POST['topic_id'];
                $level = $_POST['level'];
                $this->session->set_userdata('subject_id', $subject_id);
                $this->session->set_userdata('chapter_id', $chapter_id);
                $this->session->set_userdata('topic_id', $topic_id);
                $this->session->set_userdata('level', $level);
                $this->session->set_userdata('offset_question', $offset);
                $config['base_url'] = base_url() . "dashboard/view_questions";
                $response = $this->subscription_m->total_questions($subject_id, $chapter_id, $topic_id, $level);
                $total_row = json_decode(json_encode($response), TRUE);
                $this->session->set_userdata('total_records', $total_row[0]['rcount']);
                $config['total_rows'] = $total_row[0]['rcount'];
                $config['uri_segment'] = 3;
                $config['full_tag_open'] = '<div id="pagination">';
                $config['full_tag_close'] = '</div>';
                $this->pagination->initialize($config);
                $result['data'] = $this->subscription_m->view_questions($subject_id, $chapter_id, $topic_id, $level, $offset);
                $result = json_decode(json_encode($result), TRUE);
                $this->load->view('view_questions_new', $result);
            } else if (isset($subject_id) && isset($chapter_id) && isset($topic_id) && isset($total_row) && isset($level)) {
                $offset = 0;
                $result['data'] = $this->subscription_m->view_questions($subject_id, $chapter_id, $topic_id, $level, $offset);
                $config['total_rows'] = $total_row;
                $config['uri_segment'] = 3;
                $config['base_url'] = base_url() . "dashboard/view_questions";
                $config['full_tag_open'] = '<div id="pagination">';
                $config['full_tag_close'] = '</div>';
                $this->pagination->initialize($config);
                $result = json_decode(json_encode($result), TRUE);
                $this->load->view('view_questions_new', $result);
            } else {
                redirect('admin/display_question_list');
            }
        } else {
            $offset = trim_slashes($off);
            $this->session->set_userdata('offset_question', $offset);
            $result['data'] = $this->subscription_m->view_questions($subject_id, $chapter_id, $topic_id, $level, $offset);
            $config['total_rows'] = $total_row;
            $config['uri_segment'] = 3;
            $config['base_url'] = base_url() . "dashboard/view_questions";
            $config['full_tag_open'] = '<div id="pagination">';
            $config['full_tag_close'] = '</div>';
            $this->pagination->initialize($config);
            $result = json_decode(json_encode($result), TRUE);
            $this->load->view('view_questions_new', $result);
        }
    }

}

?>