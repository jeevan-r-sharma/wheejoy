<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
include ('Classes/PHPExcel/IOFactory.php');

class admin extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('subscription_m');
        $this->load->library('pagination');
    }

    function get_exam() {
        $json = $this->subscription_m->get_view_add_detail();
        $json = json_encode($json);
        echo $json;
    }

    function get_cf_subject() {
        $exam_id = $_POST['exam'];
        $json = $this->subscription_m->get_cf_Subjects($exam_id);
        $json = json_encode($json);
        echo $json;
    }

    function getcf_Chapters() {
        $subject_id = $_POST['subject_id'];
        $json = $this->subscription_m->get_cf_Chapters($subject_id);
        $json = json_encode($json);
        echo $json;
    }

    function get_cf_topics() {
        $chapter_id = $_POST['chapter_id'];
        $this->load->model('subscription_m');
        $array = $this->subscription_m->get_topics_list_by_cf_chapter($chapter_id);
        // print_r($array);
        $json = json_encode($array);
        print_r($json);
    }

    function get_video_list() {
        $topic_id = $_POST['topic_id'];
        $this->load->model('subscription_m');
        $array = $this->subscription_m->get_videos_by_topic($topic_id);
        $json = json_encode($array);
        print_r($json);
    }

    function get_questionSet() {
        $chapter_id = $_POST['chapter_id'];
        $this->load->model('subscription_m');
        $array = $this->subscription_m->get_questionSet_by_cf_chapter($chapter_id);
        $json = json_encode($array);
        print_r($json);
    }

    function get_synopsis() {
        $topic_id = $_POST['topic_id'];
        $this->load->model('subscription_m');
        $array = $this->subscription_m->get_synopsis($topic_id);
        $json = json_encode($array);
        print_r($json);
    }

    function delete_exam() {
        $examID = $_POST['exam_id'];
        $array = $this->subscription_m->adm_delete_exam($examID);
        print_r($array);
    }

    function delete_cf_subject() {
        $subjectID = $_POST['subject_id'];
        $array = $this->subscription_m->adm_delete_cf_subject($subjectID);
        print_r($array);
    }

    function delete_cf_chapter() {
        $chapterID = $_POST['chapter_id'];
        $array = $this->subscription_m->delete_cf_chapter($chapterID);
        print_r($array);
    }

    function delete_cf_topic() {
        $topicID = $_POST['topic_id'];
        $array = $this->subscription_m->adm_delete_cf_topic($topicID);
        print_r($array);
    }

    function insertadd_exams() {
        $name = $_POST['name'];
        $description = $_POST['description'];
        $this->load->model("subscription_m");
        $json = $this->subscription_m->insert_master_add_exam_adm($name, $description);
        $json = json_encode($json);
        echo $json;
    }

    function insertmastercf_subject() {
        $login_id = $this->session->userdata('usr_session');
        $instId = $login_id[0]->registration_no;
        $exam_id = $_POST['exam_id'];
        $subject_name = $_POST['subject_name'];
        $description = $_POST['description'];
        $json = $this->subscription_m->insert_master_cf_add_subject_adm($exam_id, $subject_name, $description, $instId);
        $json = json_encode($json);
        echo $json;
    }

    function addNewSubscription() {
        $login_id = $this->session->userdata('usr_session');
        $instId = $login_id[0]->registration_no;
        $exam_id = $_POST['exam_id'];
        $planName = $_POST['planName'];
        $planPrice = $_POST['planPrice'];
        $subj_id = $_POST['subj_id'];
        // print_r($instId.$exam_id.$planName.$planPrice);
        $json = $this->subscription_m->addNewSubscriptionM($exam_id, $planName, $planPrice, $instId, $subj_id);
        // echo($json);
        $json = json_encode($json);
        echo $json;
    }

    function insertmasterchapters() {
        $subject_id = $_POST['subject_id'];
        $name = $_POST['name'];
        $description = $_POST['description'];
        $this->load->model("subscription_m");
        $array = $this->subscription_m->insert_master_add_chapter_admin($subject_id, $name, $description);
        $array = json_encode($array);
        echo $array;
    }

    function insertmastertopic() {
        $chapter_id = $_POST['chapter_id'];
        $topic_name = $_POST['topic_name'];
        $description = $_POST['description'];
        $this->load->model("subscription_m");
        $array = $this->subscription_m->insert_master_add_topic_adm($chapter_id, $topic_name, $description);
        $json = json_encode($array);
        echo $json;
    }

    function insertVideoFile() {
        $topic_id = $_POST['topic_id'];
        $video_name = $_POST['video_name'];
        $video_desc = $_POST['video_desc'];
        $video_link = $_POST['video_link'];
        $off_link = $_POST['off_link'];
        $duration = $_POST['duration'];
        $this->load->model("subscription_m");
        $array = $this->subscription_m->insert_video_file($topic_id, $video_name, $video_desc, $video_link, $off_link, $duration);
        $json = json_encode($array);
        echo $json;
    }

    function editVideoFile() {
        $id = $_POST['id'];
        $ename = $_POST['editname'];
        $edesc = $_POST['editdesc'];
        $evideo = $_POST['editvideo'];
        $eoffline = $_POST['editsource'];
        $eduration = $_POST['editduration'];
        $this->load->model("subscription_m");
        $array = $this->subscription_m->edit_video_file($id, $ename, $edesc, $evideo, $eoffline, $eduration);
        $json = json_encode($array);
        echo $json;
    }

    function editexam() {
        $id = $_POST['eidd'];
        $ename = $_POST['ename'];
        $edesc = $_POST['edesc'];
        $this->load->model("subscription_m");
        $array = $this->subscription_m->edit_exam($id, $ename, $edesc);
        $json = json_encode($array);
        echo $json;
    }

    function editSubject() {
        $id = $_POST['eidd'];
        $ename = $_POST['ename'];
        $this->load->model("subscription_m");
        $array = $this->subscription_m->edit_subject($id, $ename);
        $json = json_encode($array);
        echo $json;
    }

    function editChapter() {
        $id = $_POST['eidd'];
        $ename = $_POST['ename'];
        $this->load->model("subscription_m");
        $array = $this->subscription_m->edit_chapter($id, $ename);
        $json = json_encode($array);
        echo $json;
    }

    function editTopic() {
        $id = $_POST['eidd'];
        $ename = $_POST['ename'];
        $edesc = $_POST['edesc'];
        $this->load->model("subscription_m");
        $array = $this->subscription_m->edit_topic($id, $ename, $edesc);
        $json = json_encode($array);
        echo $json;
    }

    function editUserProfile() {
        $id = $_POST['id'];
        $fname = $_POST['e_name'];
        $email = $_POST['e_email'];
        $u_name = $_POST['e_uname'];
        $password = $_POST['e_pass'];
        $phone = $_POST['e_contact'];
        $this->load->model("subscription_m");
        $array = $this->subscription_m->edit_user_profile($id, $fname, $email, $u_name, $password, $phone);
        $json = json_encode($array);
        echo $json;
    }

    function getExcelDatastu() {
        $this->load->helper(array('form', 'url'));
        if (0 < $_FILES['file']['error']) {
            echo 'Error: ' . $_FILES['file']['error'] . '<br>';
        } else {
            $exam_id = $_POST['exam'];
            $file_name = $_FILES['file']['name'];
            $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
            $expensions = array('xls');
            if (in_array($file_ext, $expensions) === false) {
                echo "0";
            } else {
                $excel = $file_name;
                if (!is_dir('ImportData')) {
                @mkdir('ImportData', 0777, true);
                }
                if (!is_dir('ImportData/' . $exam_id)) {
                @mkdir('ImportData/' . $exam_id, 0777, true);
                }
                $importPathFile = 'ImportData/' . $exam_id . '/' . $excel;
                move_uploaded_file($_FILES['file']['tmp_name'], $importPathFile);
                $excel_name = $excel;
            }
        }
        $inputFileName = $importPathFile;
        $objReader = new PHPExcel_Reader_Excel5();
        $objPHPExcel = $objReader->load($inputFileName);
        $sheetData = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
        $highestColumm = $objPHPExcel->setActiveSheetIndex(0)->getHighestColumn();
        $sheetData1 = PHPExcel_Cell::columnIndexFromString($highestColumm);
        $data = array_merge($sheetData);
        $data1 = ($sheetData1);
        $finaldata = array($data, $data1);
        echo json_encode($finaldata);
    }
    function import_student() {
        $login_id = $this->session->userdata('usr_session');
        if ($login_id) {
            $data = $_POST['student_records'];
            $exam_id = $_POST['exam_id'];
            $data_array = Array();
            for ($i = 0; $i < count($data); $i++) {
                $f_name = $data[$i]['f_name'];
                $l_name = $data[$i]['l_name'];
                $gender = $data[$i]['gender'];
                $phone =  $data[$i]['phone'];
                $email =  $data[$i]['email'];
                $password = $this->generateRandomPasswordString();
                $city = $data[$i]['city'];
                $college = $data[$i]['college'];
                $activationcode = $this->generateActivationCode();
                $arry = array('first_name' => $f_name, 'last_name' => $l_name, 'gender' => $gender, 'phonenumber' => $phone,
                    'email' => $email, 'password' => $password,'city_id' => $city, 'college_id' => $college,'class_id' => $exam_id ,'status' => 0,'activation_code' => $activationcode);
                array_push($data_array, $arry);
            }
            // print_r($data_array);   
            
            $result = $this->subscription_m->student_import($data_array, $exam_id);
            echo json_encode($result);
        }else {
            
            redirect("signin", "Refresh");
        }
    }
    function generateRandomPasswordString() {
        $length = 10;
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $randomString;
    }
    function generateActivationCode() {
        $act = random_string('alnum', 16);
        return $act;
    }
	// function calPdf(){
			// $chapter_id = 48;
            // $pdf_name = 'dad';
            // $type = 1;
			// $ques_file = "day"; 
			// $ans_file = "day";
			// $this->load->model("subscription_m");
		// $array = $this->subscription_m->insert_questionset_pdffile($chapter_id, $type, $pdf_name, $ques_file, $ans_file);
            // // $array = json_encode($array);
            // print_r($array);
	// }

    function insertQuestionPdfFile() {
        if ((isset($_FILES['question_file'])) && (isset($_FILES['answer_file']))) {
            $errors = array();
            $subject_id = $_POST['subject_id'];
            $chapter_id = $_POST['chapter_id'];
            $pdf_name = $_POST['pdf_name'];
            $type = $_POST['que_type'];
//                $datetime = date("Y-m-d h:i:sa");
            date_default_timezone_set("Asia/Kolkata");
            $datetime = date("Y-m-d-h-:i-:s-a");

            $ques_file = $pdf_name . '-' . $datetime . ".pdf";
            $ques_file = str_replace(':', '', $ques_file);

            $ans_file = $pdf_name . '-' . $datetime . ".pdf";
            $ans_file = str_replace(':', '', $ans_file);

            $ques_file_size = $_FILES['question_file']['size'];
            $ques_file_tmp = $_FILES['question_file']['tmp_name'];
            $ans_file_tmp = $_FILES['answer_file']['tmp_name'];
            $ques_file_type = $_FILES['question_file']['type'];
            if (!is_dir('pdf')) {
                @mkdir('pdf', 0777, true);
            }
            if (!is_dir('pdf/' . $subject_id)) {
                @mkdir('pdf/' . $subject_id, 0777, true);
            }
            if (!is_dir('pdf/' . $subject_id . '/' . $chapter_id)) {
                @mkdir('pdf/'  . $subject_id . '/' . $chapter_id, 0777, true);
            }
            if (!is_dir('pdf/' . $subject_id . '/' . $chapter_id . '/Question_files')) {
                @mkdir('pdf/' . $subject_id . '/' . $chapter_id . '/Question_files', 0777, true);
            }
            if (!is_dir('pdf/' . $subject_id . '/' . $chapter_id . '/Answer_files')) {
                @mkdir('pdf/'  . $subject_id . '/' . $chapter_id . '/Answer_files', 0777, true);
            }

            $ques_path = 'pdf/' . $subject_id . '/' . $chapter_id . '/Question_files/' . $ques_file;
            $ans_path = 'pdf/' . $subject_id . '/' . $chapter_id . '/Answer_files/' . $ans_file;
            move_uploaded_file($ques_file_tmp, $ques_path);
            move_uploaded_file($ans_file_tmp, $ans_path);
            $array = $this->callInsertQuestionSet($chapter_id, $type, $pdf_name, $ques_file, $ans_file);
            echo $array;
        }
    }
	function callInsertQuestionSet($chapter_id, $type, $pdf_name, $ques_file, $ans_file){
		$this->load->model("subscription_m");
		$array = $this->subscription_m->insertQuestionSetPdfFile($chapter_id, $type, $pdf_name, $ques_file, $ans_file);
		$array = json_encode($array);
		return $array;
	}

    function editQuestionPdfFile() {
        if ((isset($_FILES['newquestion_file'])) && (isset($_FILES['newanswer_file']))) {
            $errors = array();
            $id = $_POST['id'];
            $exam_id = $_POST['exam_id'];
            $subject_id = $_POST['subject_id'];
            $chapter_id = $_POST['chapter_id'];
            $pdf_name = $_POST['ques_name'];
            $old_ques = $_POST['oldquestion_file'];
            $old_ans = $_POST['oldanswer_file'];
//                $datetime = date("Y-m-d h:i:sa");
            date_default_timezone_set("Asia/Kolkata");
            $datetime = date("Y-m-d-h-:i-:s-a");

            $ques_file = $pdf_name . '-' . $datetime . ".pdf";
            $ques_file = str_replace(':', '', $ques_file);

            $ans_file = $pdf_name . '-' . $datetime . ".pdf";
            $ans_file = str_replace(':', '', $ans_file);

            $ques_file_size = $_FILES['newquestion_file']['size'];
            $ques_file_tmp = $_FILES['newquestion_file']['tmp_name'];
            $ans_file_tmp = $_FILES['newanswer_file']['tmp_name'];
            $ques_file_type = $_FILES['newquestion_file']['type'];

            $ques_path = 'pdf/' . $exam_id . '/' . $subject_id . '/' . $chapter_id . '/Question_files/';
            $ans_path = 'pdf/' . $exam_id . '/' . $subject_id . '/' . $chapter_id . '/Answer_files/';
            unlink("$ques_path" . "$old_ques");
            unlink("$ans_path" . "$old_ans");
            $new_qpath = $ques_path . $ques_file;
            $new_apath = $ans_path . $ans_file;
            move_uploaded_file($ques_file_tmp, $new_qpath);
            move_uploaded_file($ans_file_tmp, $new_apath);
            $this->load->model("subscription_m");
            $array = $this->subscription_m->edit_questionset_pdffile($id, $chapter_id, $pdf_name, $ques_file, $ans_file);
            $array = json_encode($array);
            echo $array;
        }
    }

    function insertSynopsisPdfFile() {
        if (isset($_FILES['synopsis_file'])) {
            $errors = array();
            $subject_id = $_POST['subject_id'];
            $chapter_id = $_POST['chapter_id'];
            $topic_id = $_POST['topic_id'];
            $pdf_name = $_POST['pdf_name'];
//                $datetime = date("Y-m-d h:i:sa");
            date_default_timezone_set("Asia/Kolkata");
            $datetime = date("Y-m-d-h-:i-:s-a");

            $syno_file = $pdf_name . '-' . $datetime . ".pdf";
            $syno_file = str_replace(':', '', $syno_file);

            $syno_file_size = $_FILES['synopsis_file']['size'];
            $syno_file_tmp = $_FILES['synopsis_file']['tmp_name'];
            $syno_file_type = $_FILES['synopsis_file']['type'];
            if (!is_dir('Synopsis')) {
                @mkdir('Synopsis', 0777, true);
            }
            if (!is_dir('Synopsis/'  . $subject_id)) {
                @mkdir('Synopsis/'  . $subject_id, 0777, true);
            }
            if (!is_dir('Synopsis/' . $subject_id . '/' . $chapter_id)) {
                @mkdir('Synopsis/' . $subject_id . '/' . $chapter_id, 0777, true);
            }
            if (!is_dir('Synopsis/' . $subject_id . '/' . $chapter_id . '/' . $topic_id . '/Synopsis_files')) {
                @mkdir('Synopsis/' . $subject_id . '/' . $chapter_id . '/' . $topic_id . '/Synopsis_files', 0777, true);
            }

            $syno_path = 'Synopsis/'. $subject_id . '/' . $chapter_id . '/' . $topic_id . '/Synopsis_files/' . $syno_file;
            move_uploaded_file($syno_file_tmp, $syno_path);
            $this->load->model("subscription_m");
            $array = $this->subscription_m->insert_synopsis_pdffile($topic_id, $syno_file);
            $array = json_encode($array);
            echo $array;
        }
    }

    function editSynopsisPdfFile() {
        if (isset($_FILES['newsynopsis_file'])) {
            $errors = array();
            $id = $_POST['id'];
            $exam_id = $_POST['exam_id'];
            $subject_id = $_POST['subject_id'];
            $chapter_id = $_POST['chapter_id'];
            $topic_id = $_POST['topic_id'];
            $synop_name = $_POST['synop_name'];
            $old_file = $_POST['oldsynopsis_file'];
//                $datetime = date("Y-m-d h:i:sa");
            date_default_timezone_set("Asia/Kolkata");
            $datetime = date("Y-m-d-h-:i-:s-a");

            $syno_file = $synop_name . '-' . $datetime . ".pdf";
            $syno_file = str_replace(':', '', $syno_file);

            $syno_file_size = $_FILES['newsynopsis_file']['size'];
            $syno_file_tmp = $_FILES['newsynopsis_file']['tmp_name'];
            $syno_file_type = $_FILES['newsynopsis_file']['type'];
            $path = 'Synopsis/' . $exam_id . '/' . $subject_id . '/' . $chapter_id . '/' . $topic_id . '/Synopsis_files/';
            unlink("$path" . "$old_file");
            $new_path = $path . $syno_file;
            move_uploaded_file($syno_file_tmp, $new_path);
            $this->load->model("subscription_m");
            $array = $this->subscription_m->edit_synopsis_pdffile($id, $topic_id, $syno_file);
            $array = json_encode($array);
            echo $array;
        }
    }

    function addExam() {
        $login_id = $this->session->userdata('usr_session');
        if($login_id){
        $this->load->model('subscription_m');
        $array['a'] = $this->subscription_m->get_view_add_detail();
        $this->load->view("add_exam", $array);
        }else{
            $this->session->set_userdata("redirect", $_SERVER['REQUEST_URI']);
            redirect('signin', 'refresh');
        }
    }

    function addSubjects() {
        $login_id = $this->session->userdata('usr_session');
        if($login_id){
        $this->load->model('subscription_m');
        $array['s'] = $this->subscription_m->get_master_subject();
        $array['a'] = $this->subscription_m->get_view_add_detail();
        $this->load->view("cf_add_subjects", $array);
        }
        else{
            $this->session->set_userdata("redirect", $_SERVER['REQUEST_URI']);
            redirect('signin', 'refresh');
        }
    }

    function addSubscription() {
        $login_id = $this->session->userdata('usr_session');
        if($login_id){
        $this->load->model('subscription_m');
        $array['s'] = $this->subscription_m->get_master_subscription();
        $array['a'] = $this->subscription_m->get_view_add_detail();
        // print_r($array);
        // print_r($login_id[0]->registration_no);
        $this->load->view("cf_add_subscription", $array);
        }
        else{
            $this->session->set_userdata("redirect", $_SERVER['REQUEST_URI']);
            redirect('signin', 'refresh');
        }
    }

    function addSubToSubscription() {
        $login_id = $this->session->userdata('usr_session');
        if($login_id){
        $this->load->model('subscription_m');
        $array['s'] = $this->subscription_m->get_master_subject();
        $array['a'] = $this->subscription_m->get_view_add_detail();
        $this->load->view("cf_add_sub_to_subscription", $array);
        }
        else{
            $this->session->set_userdata("redirect", $_SERVER['REQUEST_URI']);
            redirect('signin', 'refresh');
        }
    }

    function addChapter() {
        $login_id = $this->session->userdata('usr_session');
        if($login_id){
        $this->load->model('subscription_m');
        // print_r($login_id[0]->registration_no);
        $array['a'] = $this->subscription_m->getSubjectsByInst($login_id[0]->registration_no);
        $array['g'] = $this->subscription_m->getAllChapters();
        // print_r($array);
        $this->load->view("cf_add_chapter", $array);
        }else{
            $this->session->set_userdata("redirect", $_SERVER['REQUEST_URI']);
            redirect('signin', 'refresh');
        }
    }

    function addTopics() {
        $login_id = $this->session->userdata('usr_session');
        if($login_id){
        $array['a'] = $this->subscription_m->get_cf_topic_list();
        $array['g'] = $this->subscription_m->get_master_subject();
        $this->load->view("cf_add_topics", $array);
        }else{
            $this->session->set_userdata("redirect", $_SERVER['REQUEST_URI']);
            redirect('signin', 'refresh');
        }
    }

    function addVideo() {
        $login_id = $this->session->userdata('usr_session');
        if($login_id){
        $this->load->model('subscription_m');
        $exam = $this->subscription_m->get_master_subject();
        $dumy_value = 0;
        $video_details = $this->subscription_m->get_videos_by_topic($dumy_value);
        $array['g'] = array($exam, $video_details);
        $this->load->view("cf_add_video", $array);
        }else{
            $this->session->set_userdata("redirect", $_SERVER['REQUEST_URI']);
            redirect('signin', 'refresh');
        }
    }

    function addQuestion() {
        $login_id = $this->session->userdata('usr_session');
        if($login_id){
        $this->load->model('subscription_m');
        $exam = $this->subscription_m->get_master_subject();
        $pdf_details = $this->subscription_m->get_pdf_insertedQuestion_set();
        $array['g'] = array($exam, $pdf_details);
        $this->load->view("cf_add_question", $array);
        }else{
            $this->session->set_userdata("redirect", $_SERVER['REQUEST_URI']);
            redirect('signin', 'refresh');
        }
    }

    function addSynopsis() {
        $login_id = $this->session->userdata('usr_session');
        if($login_id){
        $this->load->model('subscription_m');
        $exam = $this->subscription_m->get_master_subject();
        $synop_details = $this->subscription_m->get_pdf_inserted_synopsis();
        $array['g'] = array($exam, $synop_details);
        $this->load->view("cf_add_synopsis", $array);
        }else{
            $this->session->set_userdata("redirect", $_SERVER['REQUEST_URI']);
            redirect('signin', 'refresh');
        }
    }

    function import_question() {
//        $partner_id = $this->sessionData();
//        if ($partner_id) {
        $data = $_POST['question_data'];
        // $inst_id = $partner_id;
        $subject_id = $_POST['subject_id'];
        $chapter_id = $_POST['chapter_id'];
        $topic_id = $_POST['topic_id'];
        $q_img_path = $_POST['q_img_path'];
        $sol_img_path = $_POST['sol_img_path'];
        $data_array = Array();
        for ($i = 0; $i < count($data); $i++) {
            $question = $data[$i][0];
            $optionA = $data[$i][1];
            $optionB = $data[$i][2];
            $optionC = $data[$i][3];
            $optionD = $data[$i][4];
            $answer = $data[$i][5];
            $solution = $data[$i][6];
            $solution = str_replace("\r\n", "", $solution);
            $is_img_sol = str_replace("\r\n", "", $data[$i][8]);
            $q_img = null;
            $sol_img = null;
            if ($data[$i][7] == 1) {
                if (!file_exists($q_img_path . '/' . $question . '.jpg')) {
                    die($question . '.jpg' . " File not found");
                } else {
                    $q_img = file_get_contents($q_img_path . '/' . $question . '.jpg');
                }
            }
            if ($is_img_sol == 1) {
                if (!file_exists($sol_img_path . '/' . $solution . '.jpg')) {
                    die($solution . '.jpg' . " File not found");
                } else {
                    $sol_img = file_get_contents($sol_img_path . '/' . $solution . '.jpg');
                }
            }
            $arry = array('subject_id' => $subject_id, 'topic_id' => $topic_id, 'question_desc' => $question, 'option_a' => $optionA,
                'option_b' => $optionB, 'option_c' => $optionC, 'option_d' => $optionD,
                'answer' => $answer, 'solution' => $solution, 'is_img_solution' => boolval($data[$i][7]),
                'solution_img_data' => $sol_img, 'image_data' => $q_img, 'is_image' => boolval($data[$i][7]), 'is_practice' => $data[$i][8], 'is_assignment' => $data[$i][9]);
            array_push($data_array, $arry);
        }
        $result = $this->subscription_m->question_import($data_array);
        echo 'Import successfull';
    }

    function getInstitute_Subjects() {
        $login_id = $this->session->userdata('usr_session');
        if($login_id){
            $json = $this->subscription_m->get_Inst_Subjects($login_id[0]->registration_no);
            $json = json_encode($json);
            echo $json;
        } 
    }


}
?>