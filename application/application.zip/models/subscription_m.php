<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Subscription_m extends CI_Model {

    function __construct() {
            parent::__construct();
    }

    function student_import($data_array, $exam_id) {
        $result = $this->db->insert_batch('user_bulk_data', $data_array);
        $sql = 'call sp_admin_bulk_studentregister(?)';
        $parameters = array($exam_id);
        $query = $this->db->query($sql, $parameters);
        $this->db->close();
        if ($query) {
			//print_r($query->result());
		$this->bulkMail($query->result());	
        return  1;
         
        }else {
        return 0;
        }
    }
    function bulkMail($record) {
		
				$config = Array(
				  'protocol' => 'smtp',
				  'smtp_host' => 'ssl://smtp.googlemail.com',
				  'smtp_port' => 465,
				  'smtp_user' => 'contact.sunilsacademy@gmail.com',
				  'smtp_pass' => 'sunilacademy123',
				  'mailtype'  => 'html', 
				  'charset'   => 'iso-8859-1',
				  //'smtp_crypto' => 'ssl',
				  'SMTPAuth' => 'true'
				);
		foreach ($record as $row) {
			// print_r($row);
				$activation_code = $row->activation_code;
				$email_id = $row->email;
				$password = $row->password;
				$fname = $row->first_name;			
				$username = $email_id;
				$pswd = $password;
				$To = $email_id;
				$Subject = "Sunil Academy Registration Mail";
				$Message = "Dear $fname,\r\n
                              Thank You For Registering with Sunil Academy.\r\n
                              Your account has been created with us, Please find your login credentials.,\n\r
                              User Name : $username
                              Password  : $pswd
          
                \r\n   Happy Practising!
           
                   Thanks & Regards,
                   Sunil Academy";

				$this->load->library('email', $config);
				
				$this->email->from('contact.sunilsacademy@gmail.com', 'Sunil Academy');
				$this->email->to($To); 
				$this->email->subject($Subject);
				$this->email->message($Message);  
				$this->email->send();
					       
			}
        return ;
    }
	    
    function insertQuestionSetPdfFile($chapter_id,$type,$pdf_name, $ques_file,$ans_file) {
            $sql = "call sp_admin_insert_pdf_file(?,?,?,?,?)";
            $parameters = array($chapter_id,$type,$pdf_name, $ques_file,$ans_file);
            $query = $this->db->query($sql, $parameters);
			// print_r($query);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function edit_questionset_pdffile($id ,$chapter_id,$pdf_name, $ques_file,$ans_file) {
            $sql = "call sp_admin_edit_pdf_file(?,?,?,?,?)";
            $parameters = array($id ,$chapter_id,$pdf_name, $ques_file,$ans_file);
            $query = $this->db->query($sql, $parameters);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function insert_synopsis_pdffile($topic_id, $syno_file) {
            $sql = "call sp_admin_insert_synopsis_file(?,?)";
            $parameters = array($topic_id, $syno_file);
            $query = $this->db->query($sql, $parameters);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function edit_synopsis_pdffile($id, $topic_id, $syno_file) {
            $sql = "call sp_admin_edit_synopsis_file(?,?,?)";
            $parameters = array($id, $topic_id, $syno_file);
            $query = $this->db->query($sql, $parameters);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function edit_exam($id, $ename, $edesc) {
            $sql = "call sp_admin_edit_exam_file(?,?,?)";
            $parameters = array($id, $ename, $edesc);
            $query = $this->db->query($sql, $parameters);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function edit_subject($id, $ename) {
            $sql = "call sp_admin_edit_subject_file(?,?)";
            $parameters = array($id, $ename);
            $query = $this->db->query($sql, $parameters);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function edit_chapter($id, $ename) {
            $sql = "call sp_admin_edit_chapter_file(?,?)";
            $parameters = array($id, $ename);
            $query = $this->db->query($sql, $parameters);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function edit_topic($id, $ename, $edesc) {
            $sql = "call sp_admin_edit_topic_file(?,?,?)";
            $parameters = array($id, $ename, $edesc);
            $query = $this->db->query($sql, $parameters);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function edit_user_profile($id, $fname, $email,$u_name,$password,$phone) {
            $sql = "call sp_admin_edit_user_profile(?,?,?,?,?,?)";
            $parameters = array($id, $fname, $email,$u_name,$password,$phone);
            $query = $this->db->query($sql, $parameters);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function edit_video_file($id, $ename, $edesc,$evideo,$eoffline ,$eduration) {
            $sql = "call sp_admin_edit_video_file(?,?,?,?,?,?)";
            $parameters = array($id, $ename, $edesc,$evideo, $eoffline,$eduration);
            $query = $this->db->query($sql, $parameters);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function insert_master_add_exam_adm($name, $description) {
            $sql = "call sp_admin_add_exams(?,?)";
            $parameters = array($name, $description);
            $query = $this->db->query($sql, $parameters);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function insert_master_cf_add_subject_adm($exam_id,$subject_id, $description, $instId) {
            $sql = "call sp_admin_insert_subject(?,?,?,?)";
            $parameters = array($exam_id,$subject_id, $description,$instId);
            $query = $this->db->query($sql, $parameters);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }

    function addNewSubscriptionM($exam_id, $planName, $planPrice, $instId, $subj_id) {
            $sql = "call sp_admin_insert_subscription(?,?,?,?)";
            $parameters = array($exam_id,$planName, $planPrice, $instId);
            $query = $this->db->query($sql, $parameters);
            // $this->db->close();
            if ($query) {
                 $result = $query->result();
                $subsc_id = $result[0]->subscription_id;
                $c = 0;
            $count = count($subj_id);
            while ($c < $count) {
                $subject_id = $subj_id[$c];
                $array_data[$c] = array("subsc_id" => $subsc_id, "ref_subject_id" => $subject_id);
                $c = $c + 1;
            }
            $this->db->close();
            $this->db->insert_batch('inst_cf_sub_subjects', $array_data);
                // print_r($subsc_id);
                return $query->result();
            } else {
                return null;
            }
    }
    function insert_master_add_chapter_admin($subject_id, $name,$description) {
            $sql = "call sp_admin_insert_chapter(?,?,?)";
            $parameters = array($subject_id, $name,$description);
            $query = $this->db->query($sql, $parameters);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function insert_master_add_topic_adm($chapter_id, $topic_name, $description) {
            $sql = "call sp_admin_insert_topic(?,?,?)";
            $parameters = array($chapter_id, $topic_name, $description);
            $query = $this->db->query($sql, $parameters);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function insert_video_file($topic_id, $video_name, $video_desc, $video_link,$off_link, $duration) {
            $sql = "call sp_admin_insert_video_file(?,?,?,?,?,?)";
            $parameters = array($topic_id, $video_name, $video_desc,$video_link,$off_link,$duration);
            $query = $this->db->query($sql, $parameters);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function adm_delete_exam($examID) {
            $sql = "call sp_admin_delete_exams(?)";
            $parameter = array($examID);
            $query = $this->db->query($sql, $parameter);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return NULL;
            }
    }
    function adm_delete_cf_subject($subjectID) {
            $sql = 'delete from inst_ref_subjects where id = '.$subjectID.';';
            $query = $this->db->query($sql);
            if ($query) {
                return $query->result();
            } else {
                return NULL;
            }
    }
    function adm_delete_cf_chapter($chapterID) {
            $sql = "call sp_adm_delete_cf_chapter(?)";
            $parameter = array($chapterID);
            $query = $this->db->query($sql, $parameter);
            
            if ($query) {
                return $query->result();
            } else {
                return NULL;
            }
    }
	
	function delete_cf_chapter($chapterID) {
        $sql = 'Call sp_admin_delete_chapters_details(?)';
        $parameters = array($chapterID);
        $query = $this->db->query($sql, $parameters);
        $this->db->close();
        if ($query) {
            return $query->result();
        } else {
            return null;
        }
    }
    function adm_delete_cf_topic($topicID) {
            $sql = "call sp_admin_delete_topic_details(?)";
            $parameter = array($topicID);
            $query = $this->db->query($sql, $parameter);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return NULL;
            }
    }
    function get_view_add_detail() {
            $sql = "CALL sp_admin_exam_details()";
            $parameter = array();
            $query = $this->db->query($sql, $parameter);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return NULL;
            }
    }
        function getSubscriptionsByInst($login_id) {
            // print_r($login_id);
            $sql = 'SELECT * FROM inst_subscription_details where inst_id = '.$login_id.';';
            $query = $this->db->query($sql);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return NULL;
            }
    }
    function get_master_subject() {
            $sql = 'select * from inst_ref_subjects order by id asc;';
            $query = $this->db->query($sql);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return NULL;
            }
    }    
    function get_master_subscription() {
            $sql = 'select * from inst_subscription_details;';
            $query = $this->db->query($sql);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return NULL;
            }
    }
    function get_cf_chapters_list() {
            $sql = "CALL sp_admin_get_chapters_details()";
            $parameter = array();
            $query = $this->db->query($sql, $parameter);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function get_cf_topic_list() {
            $sql = "CALL sp_admin_get_topic_details()";
            $parameter = array();
            $query = $this->db->query($sql, $parameter);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function get_pdf_insertedQuestion_set() {
            $sql = "CALL sp_admin_get_pdf_questionset_details()";
            $parameter = array();
            $query = $this->db->query($sql, $parameter);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function get_pdf_inserted_synopsis() {
            $sql = "CALL sp_admin_get_synopsis_details()";
            $parameter = array();
            $query = $this->db->query($sql, $parameter);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function get_cf_subjects($exam_id) {
            $sql = 'Call sp_admin_get_subject_details_byid(?)';
            $parameters = array($exam_id);
            $query = $this->db->query($sql, $parameters);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }

    function getSubjectsByInst($instId) {
            $sql = 'select * from inst_ref_subjects where inst_id = '.$instId;
            // print_r($instId);
            $query = $this->db->query($sql);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function get_cf_Chapters($subject_id) {
            $sql = 'Call sp_admin_get_chapter_details_byid(?)';
            $parameters = array($subject_id);
            $query = $this->db->query($sql, $parameters);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function get_topics_list_by_cf_chapter($chapter_id) {
            $sql = "CALL sp_admin_get_topics_details_byid(?)";
            $parameter = array($chapter_id);
            $query = $this->db->query($sql, $parameter);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null; 
            }
    }
    function get_videos_by_topic($topic_id) {
            $sql = "CALL sp_admin_get_video_list_bytopic(?)";
            $parameter = array($topic_id);
            $query = $this->db->query($sql, $parameter);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function get_questionSet_by_cf_chapter($chapter_id) {
            $sql = "CALL sp_admin_get_question_set(?)";
            $parameter = array($chapter_id);
            $query = $this->db->query($sql, $parameter);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function get_synopsis($topic_id) {
            $sql = "CALL sp_admin_get_synopsis(?)";
            $parameter = array($topic_id);
            $query = $this->db->query($sql, $parameter);
            $this->db->close();
            if ($query) {
                return $query->result();
            } else {
                return null;
            }
    }
    function question_import($data_array) {
            $result = $this->db->insert_batch('questions_bank', $data_array);
            return $result;
    }

    function get_Inst_Subjects($inst_id) {
        $sql = 'select * from inst_ref_subjects where inst_id = '.$inst_id.' and status = 1';
        $query = $this->db->query($sql);
        if ($query) {
            return $query->result();
        } else {
            return null;
        }
    }    

    function getAllChapters() {
        $sql = 'select chap.id, chap.name chapName, refSubjects.description subName
from chapters chap
inner join inst_ref_subjects refSubjects on refSubjects.id = chap.subject_id';
        $query = $this->db->query($sql);
        if ($query) {
            return $query->result();
        } else {
            return null;
        }
    }

    
}