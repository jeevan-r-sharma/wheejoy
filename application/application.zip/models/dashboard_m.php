<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard_m extends CI_Model
{

//    public $db = "";
    function __construct()
   {
       parent::__construct();
   }

    function get_daily_subscription_adm($limit,$offset)
    {
        $sql = 'CALL sp_admin_get_today_subscription(?,?)';          
        $parameters = array($limit,$offset);
        $query = $this->db->query($sql, $parameters);
        $this->db->close();
        if ($query)
        {
            return $query->result();
        }
         else {
             return null;
         }
    }
    function updateUserExam_m($exam_id,$user_id)
    {
         $sql = 'call sp_update_user_exam(?,?)';
        $parameter = array($exam_id,$user_id);
        $query = $this->db->query($sql,$parameter);
        $this->db->close();
        if($query)
        {
            return $query->result();
        }
        else
        {
            return NULL;
        }
    }
    function today_registration_count()
    {
        $sql = 'CALL sp_admin_get_registration_count()';          
        $parameters = array();
        $query = $this->db->query($sql, $parameters);
        $this->db->close();
        if ($query)
        {
            return $query->result();
        }
         else {
             return null;
         }
    }
      function get_admission_details_adm()
    {
        $sql = 'CALL sp_get_admission_details_adm()';          
        $parameters = array();
        $query = $this->db->query($sql, $parameters);
        if ($query)
        {
             return $query->result();
        }
         else {
             return null;
         }
    }
     function get_monthly_subscription_adm()
    {
        $sql = 'CALL sp_get_monthly_subscription_adm()';          
        $parameters = array();
        $query = $this->db->query($sql, $parameters);
        if ($query)
        {
             return $query->result();
        }
         else {
             return null;
         }
    }
    
    function total_admissions_adm()
    {
        $sql = 'CALL sp_total_admissions_adm()';          
        $parameters = array();
        $query = $this->db->query($sql, $parameters);
        $this->db->close();
        if ($query)
        {
             return $query->result();
        }
         else {
             return null;
         }
    }
    function check_email_exists($emailid) {
        $array = array('email' => $emailid);
        $query = $this->db->get_where('user_details', $array);
        $this->db->close();
        if ($query->num_rows() > 0) {
            return 1;
        } else {
            return false;
        }
    }
    function check_phone_number_exists($contact) {
        $array = array('phonenumber' => $contact);
        $query = $this->db->get_where('user_details', $array);
        $this->db->close();
        if ($query->num_rows() > 0) {
            return 1;
        } else {
            return false;
        }
    }
    
    function search_student_by_admin_m($fname,$lname,$emailid,$phone)
    {
         $sql = 'call sp_admin_search_user_details(?,?,?,?)';
        $parameter = array($fname,$lname,$emailid,$phone);
        $query = $this->db->query($sql,$parameter);
        $this->db->close();
        if($query)
        {
            return $query->result();
        }
        else
        {
            return NULL;
        }
    }
    function get_ft_user_details()
    {
         $sql = 'call sp_get_ft_user_details()';
        $parameter = array();
        $query = $this->db->query($sql,$parameter);
        if($query)
        {
            return $query->result();
        }
        else
        {
            return NULL;
        }
    }
         function get_user_details()
         {
             $sql = 'call sp_get_user_details()';
            $parameter = array();
            $query = $this->db->query($sql,$parameter);
            if($query)
            {
                return $query->result();
            }
            else
            {
                return NULL;
            }
        }
        
        public function fetch_data($limit, $id)
        {
            $this->db->limit($limit);
            $this->db->where('id', $id);
            $parameter = array();
            $query = $this->db->get("CET_registration");
            if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
            $data[] = $query->result();
            }
                return $data;
            }
            return false;
        }
     function today_subcription_count_adm()
    {
        $sql = 'SELECT count(`userid`) as a FROM `user_details` WHERE DATE(`created_on`)=curdate()';
        $parameter = array();
        $query = $this->db->query($sql,$parameter);
        if($query)
        {
            return $query->result();
        }
        else
        {
            return NULL;
        }
    }
    function get_Overall_Subscription()
    {
//        $sql='select count(id) as id from user_subscriptions where status=1 and amount_paid>0';
        $sql='select count(userid) as id from user_details where status=1';
        $parameter = array();
        $query = $this->db->query($sql,$parameter);
        if($query)
        {
          return $query->result();
         
        }
        else
        {
            return Null;
        }
    }
  
    function record_admin_users_count()
    {
     $sql = "select concat(a.first_name,' ',a.last_name) as F_name,a.email,a.phonenumber,d.name as exam,c.name as City,b.name as College,a.created_on as Date from user_details a
            inner join college_details b on a.college_id=b.id
            inner join cf_city_details c on c.id = a.city_id
            inner join exams d on a.class_id=d.id
            order by a.created_on desc";
       //$sql = "CALL sp_admin_reg_count()";
           return $this->db->query($sql)->num_rows();
    }
    function record_adm_cet_count()
    {
     $sql = "CALL sp_admin_get_count_user_details()";
     $parameter = array();
      $query = $this->db->query($sql,$parameter);
        $this->db->close();
        if($query)
        {
          return $query->result();
         
        }
        else
        {
            return Null;
        }
    }

    function get_admin_user_data($limit, $offset)
    {
     $sql = "CALL sp_admin_user_registration_details(?,?)";
        $parameter = array($limit, $offset);
        $query = $this->db->query($sql,$parameter);
        $this->db->close();
        if($query)
        {
          return $query->result();
         
        }
        else
        {
            return Null;
        }
    }
    function get_admin_user_details($userid)
    {
     $sql = "CALL sp_admin_get_user_details(?)";
        $parameter = array($userid);
        $query = $this->db->query($sql,$parameter);
        $this->db->close();
        if($query)
        {
          return $query->result();
         
        }
        else
        {
            return Null;
        }
    }
   
    
   
    
    function get_week_subscription_adm()
    {
        $sql = 'Call sp_admin_weekly_subcription_count()';
        $parameter = array();
        $query = $this->db->query($sql,$parameter);
        if($query)
        {
            return $query->result();
        }
        else{
            return null;
        }
    }
    
    function get_monthly_subscription_count_adm()
    {
        $sql = 'Call sp_admin_month_subscription_count()';
        $parameter = array();
        $query = $this->db->query($sql,$parameter);
        if($query)
        {
            return $query->result();
        }
        else
        {
            return null;
        }
    }
    
    
    function today_subscription_details()
    {
        $sql = 'CALL sp_admin_get_today_subcription_count()';
        $parameter = array();
        $query = $this->db->query($sql,$parameter);
        if($query)
        {
            return $query->result();
        }
        else
        {
            return null;
        }
    }
    function insert_user_by_admin_m($fname,$lname,$gender,$contact,$email,$password,$exam_id,$city_id,$college_id)
    {
        $sql = 'CALL sp_admin_insert_userdetails(?,?,?,?,?,?,?,?,?)';
        $parameter = array($fname,$lname,$gender,$contact,$email,$password,$exam_id,$city_id,$college_id);
        $query = $this->db->query($sql,$parameter);
        if($query)
        {
            return $query->result();
        }
        else
        {
            return null;
        }
    }
    
}

?>
